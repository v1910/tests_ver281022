//FooterQuestionTest.js - Footer Question for Test

import { useSelector, useDispatch } from 'react-redux';

//import './FooterQuestionTest.scss';
import './FooterQuestionTest.css';

import imgSection1RightTestFinish   from './Group303.svg';

import imgSection1RightTestStart    from './Group411_Head.svg';

import { CorrectAnswersTests } from '../correctAnswersTests/CorrectAnswersTests.js';

import React from 'react';

//import  parse from 'html-react-parser';

///home/vik/Public/tests_v4/node_modules/sass-loader

export function FooterQuestionTest(props)  {//------------------------------------------------
//console.log('FooterQuestionTest--------------')

    function showNoAnswer () { //do not show selected result

        let correctAnswerId  = 'id' + (current_question*10 + selected_answer);
//console.log('showNoAnswer:  selected_answer=',selected_answer);              
//console.log('showNoAnswer:  correctAnswerId=',correctAnswerId);            
//console.log('showNoAnswer:  work=',work);            
        document.getElementById(correctAnswerId).style.backgroundColor  = colorWhite;
        document.getElementById(correctAnswerId).style.color            = colorBlue; //blue
        document.getElementById('img' + (current_question*10 + selected_answer)).src = workAnswerSymbolWhite[selected_answer];

    } // end of showAnswer


    function correctIncorrectAnswers() { // show correct and Incorrect Answers -------------
        //console.log('onClickFooterQuestionTestResults================--------------')         
        let counter                 = 0;
        let answerBackgroundColor   = null;
        let answerImg               = null;
        let answerColor             = null;
        let commentColor            = null;
        let commentTxt              = null;
        let commentDisplay          = null;
        let currQuestProps          = [];

//console.log('current_question=',current_question, 'count_correct_answer[current_question]=',count_correct_answer[current_question]);

        // defenition of currQuestProps
        arr_val = tests[currentTest][current_question]; // data of the curent question of the current test    
        selected_answer = count_correct_answer[current_question];
        correct_answer = arr_val.C_A - 1;
        
        for (let key in arr_val) {
            counter++; //count of lines in a question (question, number correct answer, answers)
        }

        for(let i=0; i<=counter-4; i++){

            answerBackgroundColor   = colorWhite;
            answerImg               = workAnswerSymbolWhite[i];
            answerColor             = colorBlue; //blue
            commentDisplay          = 'none';

            if( (i === correct_answer) && (selected_answer === correct_answer) ) {
                answerBackgroundColor   = colorWhite;
                answerImg               = workAnswerSymbolWhite[i];
                answerColor             = colorBlue; //blue
                commentTxt              = 'Correct (your answer)';
                commentColor            = colorBlue; //blue
                commentDisplay          = 'block';
            }
            else {
                if(i === correct_answer) { // (selected_answer !== correct_answer)
                    answerBackgroundColor   = colorWhite;
                    answerImg               = workAnswerSymbolWhite[i];
                    answerColor             = colorBlue; //blue
                    commentTxt              = 'Correct';
                    commentColor            = colorBlue; //blue
                    commentDisplay          = 'block';
                } else {
                        if( i === selected_answer ) { // (i !== correct_answer) 
                            answerBackgroundColor   = colorLightRed; //light red
                            answerImg               = workAnswerSymbolRed[i];
                            answerColor             = colorWhite; 
                            commentTxt              = 'Incorrect (your answer)';
                            commentColor            = colorRed; //red
                            commentDisplay          = 'block';
                        }
                }
            }
            
            currQuestProps[i] = {
                answerBackgroundColor: answerBackgroundColor,
                answerImg: answerImg,
                answerColor: answerColor,
                commentColor: commentColor,
                commentTxt: commentTxt,
                commentDisplay: commentDisplay
            } 

        }//for

//console.log('correctIncorrectAnswers: selected_answer=', selected_answer, ' currQuestProps[i].answerImg=', currQuestProps[selected_answer].answerImg);

        dispatch({type: 'FooterQuestionTest_currQuestProps',  
            payload: {
                currQuestProps: currQuestProps
            }
        });


    }// end of correctIncorrectAnswers   --------------------     


    function onClickFooterQuestionTestNext() {
//console.log('onClickFooterQuestionTest================--------------')     
        let textSection1LeftTest     = null;
        let imgSection1RightTestWork = null;
        
        showButtonRulesWork      = false;

        current_question++;
        current_question_plus1++;

        styleNext = {display: 'none'}; //not show Next button 

//        if (( current_question === count_questions_test )) { 
//            styleNext = {display: 'none'}; //not show Next button 
//        }

//console.log('FooterQuestionTest: current_question=',current_question)
//console.log('FooterQuestionTest: count_questions_test=',count_questions_test)  
//console.log('FooterQuestionTest: showResults=',showResults)

        if( ( current_question === count_questions_test ) && ( !showResults ) ) {
            clearInterval(X_setInterval); 
            current_question            = count_questions_test - 1;
            current_question_plus1      = count_questions_test;
            showButtonResults           = true;
//            imgSection1RightTest        = imgSection1RightTestFinish;
            imgSection1RightTestWork    = imgSection1RightTestFinish;
            textSection1LeftTest        = <><span>Congratulations!</span><div>You have completed the test.</div></>;
            //return white color before choosing
            showNoAnswer();
        }else {
            textSection1LeftTest     = 'Welcome to the English level tests!';
            imgSection1RightTestWork =  imgSection1RightTestStart;
//            buttonNext                  = document.getElementById('footerNextButton');
//            buttonNext.disabled         = false; //unlock Next button
        }

//        if(( current_question === count_questions_test ) && ( !showResults ) ) {
//        }

//console.log('FooterQuestionTest====================== imgSection1RightTestWork=',imgSection1RightTestWork);


        if ( showResults )  {

            imgSection1RightTestWork    = imgSection1RightTestFinish;

            textSection1LeftTest        = <><span>Congratulations!</span><div>You have completed the test.</div></>;

            styleNext = {display: 'block'}; // show Next button 

            showButtonRulesWork = true;

            if ( current_question === ( count_questions_test - 1 ) ) {
                styleNext = {display: 'none'}; //not show Next button 
            }

            if ( current_question === count_questions_test ) {
                current_question            = count_questions_test - 1;
                current_question_plus1      = count_questions_test;
                styleNext                   = {display: 'none'}; //not show Next button 
            }
        }

        dispatch({type: 'FooterQuestionTest_current_question',  
        payload: {
            current_question:         current_question,
            current_question_plus1:   current_question_plus1,
            styleNext:                styleNext
        }
        });

        textSection1Left = (             //for section1 (tests)
            <div className='contTitleTextTest'>           
                <div id='titleTextSection1Tests'>
                    Home > TEST {currentTest + 1}, level {numberLevel} > <span id='titleTextSection1TestsQuestion'>Question {current_question_plus1}</span> 
                </div> 
                <div>
                    {textSection1LeftTest}
                </div>  
            </div> );

        
        imgSection1Right =  (
            <div id='contImgTest'>
                <img  id='imgGroup411Head' src={imgSection1RightTestWork} />
            </div>
        );  

        dispatch({type: 'InitSection1HomePage', 
            payload: {
                imgSection1Right: imgSection1Right,
                textSection1Left: textSection1Left
            }
        });     

        dispatch({type: 'FooterQuestionTest_showButtonResults',  
                payload: {
                    showButtonResults: showButtonResults
                }
        });

        if ( showResults ) {//&& ( current_question === ( count_questions_test -1 )))  {
            correctIncorrectAnswers();
        }

        dispatch({type: 'FooterQuestionTest_showRules',  
            payload: {
                showRules:          false, //show rules for this question
                currentRules:       null  // current Rules
            }
        });

        dispatch({type: 'FooterQuestionTest_showButtonRules',  
            payload: {
                showButtonRules:    showButtonRulesWork   
            }
        });

    } // end of onClickFooterQuestionTestNext ----


    function onClickFooterQuestionTestBack() {
        //console.log('onClickFooterQuestionTestBack================--------------')     
        showButtonRulesWork = false;

        current_question--;
        current_question_plus1--;

        selected_answer = count_correct_answer[current_question];

        dispatch({type: 'FooterQuestionTest_current_question',  
            payload: {
                current_question:         current_question,
                current_question_plus1:   current_question_plus1
            }
        }); 

        if(showResults) {
            imgSection1RightTest        = imgSection1RightTestFinish;
            textSection1Left            = <><span>Congratulations!</span><div>You have completed the test.</div></>;
            showButtonRulesWork         = true;
            imgSection1Right =  (
                <div id='contImgTest'>
                    <img  id='imgGroup411Head' src={imgSection1RightTest} />
                </div>
            );  
//            showNoAnswer();
            correctIncorrectAnswers();
        }else {
            textSection1Left  = 'Welcome to the English level tests!';
        }

//onsole.log('FooterQuestionTest-current_question=',current_question);
//console.log('FooterQuestionTest---state_blue_red= ',state_blue_red[current_question-1][0]);
//console.log('FooterQuestionTest---state_blue_red= ',state_blue_red[current_question][0]);

        //for section1 (tests)
        textSection1Left = (
            <div className='contTitleTextTest'>           
                <div id='titleTextSection1Tests'>
                    Home > TEST {currentTest + 1}, level {numberLevel} > <span id='titleTextSection1TestsQuestion'>Question {current_question_plus1}</span> 
                </div> 
                <div>
                    {textSection1Left}
                </div>  
            </div> );

        dispatch({type: 'InitSection1HomePage', 
            payload: {
                imgSection1Right: imgSection1Right,
                textSection1Left: textSection1Left
            }
        }) 

        dispatch({type: 'FooterQuestionTest_showRules',  
            payload: {
                showRules:          false, //show rules for this question
                currentRules:       null  // current Rules
            }
        });
        dispatch({type: 'FooterQuestionTest_showButtonRules',  
            payload: {
                showButtonRules:    showButtonRulesWork   
            }
        });
        
    } // end of onClickFooterQuestionTestBack ----


    function onClickFooterQuestionTestRules() {
        //console.log('onClickFooterQuestionTestRules================--------------')  
//console.log('FooterQuestionTest: arr_val.R=',arr_val.R)        
        
        let keyCurrentRules = arr_val.R;

        let currentRulesWork = CorrectAnswersTests();

        showRules = true;

//console.log('====================FooterQuestionTest: currentRulesWork=',currentRulesWork);        

        currentRules = currentRulesWork[keyCurrentRules];

//console.log('====================FooterQuestionTest: currentRules=',currentRules);        

        dispatch({type: 'FooterQuestionTest_showRules',  
            payload: {
                showRules:          showRules, //show rules for this question
                currentRules:       currentRules  // current Rules
            }
        });
        dispatch({type: 'FooterQuestionTest_showButtonRules',  
            payload: {
                showButtonRules:    false   
            }
        });
    } // end of onClickFooterQuestionTestRules ----


    function onClickFooterQuestionTestResults() { // show results -------------
        //console.log('onClickFooterQuestionTestResults================--------------')         

        showResults = true;

        dispatch({type: 'FooterQuestionTest_showResults',  
            payload: {
                showResults:  showResults, //true - show results for this question
            }
        }); 
        dispatch({type: 'FooterQuestionTest_showButtonResults',  
            payload: {
                showButtonResults:  false   
            }
        });         
//console.log('current_question=',current_question, 'count_correct_answer[current_question]=',count_correct_answer[current_question]);

        correctIncorrectAnswers();
       
        dispatch({type: 'FooterQuestionTest_showRules',  
            payload: {
                showRules:          false, //not show rules for this question
                currentRules:       null  // no current Rules
            }
        });

        dispatch({type: 'FooterQuestionTest_showButtonRules',  
            payload: {
                showButtonRules:    true   
            }
        });


    } // end of onClickFooterQuestionTestResults ----

    
    let current_question        = null;
    let current_question_plus1  = null;
    let textSection1Left        = null;
    let currentTest             = null;
    let numberLevel             = null;
    let imgSection1RightTest    = null;
    let count_questions_test    = null;            
    let buttonTestFooter        = null;
    let showResults             = null;
    let showButtonResults       = null;
    let showButtonResultsWork   = null;
    let showRules               = null;
    let showButtonRules         = null;
    let showButtonRulesWork     = null;    
    let showButtonNextWork      = null; 
    let showButtonBacktWork     = null; 
    let selected_answer         = null;
    let correct_answer          = null;
    let workAnswerSymbolBlue    = null;
    let workAnswerSymbolWhite   = null;
    let workAnswerSymbolRed     = null;
    let arr_val                 = null;
    let count_correct_answer    = null;
    let tests                   = null;
    let styleNext               = null;
    let X_setInterval           = null;
    let imgSection1Right        = null;
    let colorBlue               = null;
    let colorRed                = null;
    let colorLightRed           = null;
    let colorWhite              = null;
    let blockShowRules          = null;
    let currentRules            = null;
    let parse                   = null; 
    let workConv                = null; 
    

    let dispatch = useDispatch();  

    current_question          = useSelector((store) => store.current_question); 
    current_question_plus1    = useSelector((store) => store.current_question_plus1);    
    currentTest               = useSelector((store) => store.currentTest); 
    numberLevel               = useSelector((store) => store.numberLevel);     
    imgSection1RightTest      = useSelector((store) => store.imgSection1RightTest);   
    current_question_plus1    = useSelector((store) => store.current_question_plus1);  
    count_questions_test      = useSelector((store) => store.count_questions_test); //the count of questions in the test
    showResults               = useSelector((store) => store.showResults);     
    showButtonResults         = useSelector((store) => store.showButtonResults);      
    showRules                 = useSelector((store) => store.showRules);     
    showButtonRules           = useSelector((store) => store.showButtonRules);
    selected_answer           = useSelector((store) => store.selected_answer);
    workAnswerSymbolBlue      = useSelector((store) => store.workAnswerSymbolBlue);
    workAnswerSymbolWhite     = useSelector((store) => store.workAnswerSymbolWhite);
    workAnswerSymbolRed       = useSelector((store) => store.workAnswerSymbolRed);
    tests                     = useSelector((store) => store.tests);     
    count_correct_answer      = useSelector((store) => store.count_correct_answer);     
    styleNext                 = useSelector((store) => store.styleNext);     
    X_setInterval             = useSelector((store) => store.X_setInterval);
    colorBlue                 = useSelector((store) => store.colorBlue);
    colorRed                  = useSelector((store) => store.colorRed);
    colorLightRed             = useSelector((store) => store.colorLightRed);
    colorWhite                = useSelector((store) => store.colorWhite);
    currentRules              = useSelector((store) => store.currentRules);


    arr_val  = tests[currentTest][props.numberQuestion]; // data of the curent question of the current test


//console.log('FooterQuestionTest------- 1 imgSection1RightTest=',imgSection1RightTest);
//console.log('FooterQuestionTest--============= -state_blue_red= ',state_blue_red[current_question][0]);
//console.log('FooterQuestionTest--============= styleNext= ',styleNext);

    correct_answer = arr_val.C_A - 1;
//console.log('styleNext=',styleNext)
    if( ( current_question < count_questions_test ) && ( styleNext != {display: 'none'} ) ) 
        showButtonNextWork = <div id='footerNextButton' style={styleNext} onClick={() => onClickFooterQuestionTestNext()} > Next </div>
    else
        showButtonNextWork = null;

    if(current_question > 0) 
        showButtonBacktWork = <div id='footerBackButton' onClick={() => onClickFooterQuestionTestBack()} > Back </div>
    else
        showButtonBacktWork = null;

    if(showButtonResults) 
        showButtonResultsWork = <div id='footerResultsButton' onClick={() => onClickFooterQuestionTestResults()} > Show results </div>
    else
        showButtonResultsWork = null;

    if(showButtonRules) 
        showButtonRulesWork = <div id='footerRulesButton' onClick={() => onClickFooterQuestionTestRules()} > Show rules </div>
    else
        showButtonRulesWork = null;

    if (showRules) {        
        parse = require('html-react-parser');
        workConv = parse(currentRules);
//console.log('workConv', workConv);
        blockShowRules = workConv;
    } else {
        blockShowRules = null;
    } //else

//console.log('showRules=', showRules);
//console.log('blockShowRules=', blockShowRules);

    buttonTestFooter = (
        <>
            {blockShowRules}
            <div id='twoButtonsFooterTest'>
                {showButtonBacktWork}
                {showButtonNextWork}
                {showButtonResultsWork}
                {showButtonRulesWork}
            </div>
        </>
    )

    return buttonTestFooter;

}//end of FooterQuestionTest ---