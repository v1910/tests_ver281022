//InitSection1HomePage.js- Initializetion of data of Section1 of Home Page --------------------------

import React          from "react";

import { useSelector, useDispatch } from 'react-redux';

import  "./InitSection1HomePage.css";

import group411_Head  from "./Group411_Head.svg";

let textSection1Left     = null;
let imgSection1Right     = null;
let textSection1LeftInit = null;
let imgSection1RightInit = null;
let currentBranchSite    = null;

/*html text for section1 - left part */
// screenSize - screen Size, tabletMaxScreenSize - Max Screen Size of tablet
export function InitSection1HomePage() {
console.log('InitSection1HomePage()---');
  let dispatch = useDispatch();

  imgSection1RightInit      = useSelector((store) => store.imgSection1RightInit);
  textSection1LeftInit      = useSelector((store) => store.textSection1LeftInit);
  currentBranchSite         = useSelector((store) => store.currentBranchSite);  

  imgSection1Right = (currentBranchSite  === 'Home') 
      ? (<div id='group411_Head'>
          <img  id='imgGroup411Head' key='img1' src={group411_Head} />
        </div>)

      : imgSection1RightInit;
  


  textSection1Left = (currentBranchSite  === 'Home') 
      ? textSection1LeftInit
      : textSection1LeftInit;


  dispatch({type: 'InitSection1HomePage', 
    payload: {
      imgSection1Right: imgSection1Right,
      textSection1Left: textSection1Left
    }
  })
console.log('InitSection1HomePage()---textSection1Left=',textSection1Left);
    return null;

} // end of InitSection1HomePage

