// OnClickTest - selection of the test (numberTest with numberLevel)
import React from "react";

import { useSelector, useDispatch } from 'react-redux';

export function onClickTest(numberTest, numberLevel) {

console.log('onClickTest: numberTest=',numberTest); 

//        let currQuestProps = null;



    let dispatch  = useDispatch();

    let X_setInterval  = useSelector((store) => store.X_setInterval);

/*
    let currentTest = numberTest-1;
    let current_question = 0;
    let current_question_plus1 = 1;
    let count_correct_answer = Array(count_questions_test).fill(null);  // count of correct answers for every question

    clearInterval(X_setInterval);

    dispatch({ type: 'MenuMainPage_onClickTest', payload: 
        {   
            currentTest:            currentTest,
            currentBranchSite:      'Tests',
            initSection3HomePage:   null,
            numberLevel:            numberLevel,
            current_question:       current_question,
            current_question_plus1: current_question_plus1,
            countDownDate_qst:      new Date().getTime(), // start time for the choosing test
            activeTest:             true
        }
    });

    dispatch({type: 'FooterQuestionTest_showResults',  
        payload: {
            showResults:  false, //true - show results for this question
        }
    }); 

    dispatch({type: 'FooterQuestionTest_showButtonRules',  
        payload: {
            showButtonRules:    false
        }
    });

    dispatch({type: 'MenuMainPage_styleNext',  
        payload: {
            styleNext:                {display: 'none'}
        }
    });

//console.log('onClickTest: current_question=',current_question);     

    //for section1 (tests)
    textSection1LeftTest = (
        <div className='contTitleTextTest'>           
            <div id='titleTextSection1Tests'>
                Home > TEST {numberTest}, level {numberLevel} > <span id='titleTextSection1TestsQuestion'>Question {current_question_plus1}</span> 
            </div> 
            <div>
                Welcome to the English level tests!
            </div>  
        </div> );

    dispatch({type: 'InitSection1HomePage', 
        payload: {
            imgSection1Right: imgSection1RightTest,
            textSection1Left: textSection1LeftTest
        }
    });   

    count_questions_test        = tests[currentTest].length; // amount of questions in current test
    
//        state_blue_red_user         = Array(count_questions_test).fill(-1);// user answer 

    state_blue_red_corr         = Array(count_questions_test).fill(-1);// correct answer 

    state_count_time_test       = Array(count_questions_test).fill(0);// state of close button                                                             

//        state_count_time_question   = []; // state of count time question

    
    
//        count_time_test             = Array(count_questions_test).fill('00:00'); // all time for the current test
    

    dispatch({type: 'MenuMainPage_Init', 
        payload: {
            state_blue_red_user:  Array(count_questions_test).fill(-1),// user answer ,
            state_blue_red_corr:  Array(count_questions_test).fill(-1),// correct answer 
            count_time_test:      '00:00', // all time for the current test
            count_time_question:  Array(count_questions_test).fill('00:00'),  // all time for the current question
            countDownDate:        new Date().getTime(), // start time for the chosing test
            firstTimer:           null,
            count_questions_test: count_questions_test,
            count_correct_answer: count_correct_answer
        }
    });
*/
}// end of onClickTest---------------
