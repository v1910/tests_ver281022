//ShowCurrentTest.js:   show curent test--------------------------

import React from "react";

import './ShowCurrentTest.css';

import {QuestionTest} from "../questionTest/QuestionTest.js";

import {AnswerTest} from "../answerTest/AnswerTest.js";

import {FooterQuestionTest} from "../footerQuestionTest/FooterQuestionTest.js";

import { useSelector, useDispatch } from 'react-redux';

//import  "../scrollToTopBtn/scrollToTopBtn.css";

//import  "../scrollToTopBtn/scrollToTopBtn.js";


let count_time_question       = null;
let count_time_test           = null;
let X_setInterval             = 0;
let correct_answer            = null;
let tests                     = null;
let count_correct_answer      = null;
let countDownDate             = null;
let countDownDate_qst         = null; // start time for the chose question
let current_question          = 0;
let currentTest               = null;
let count_questions_test      = null;
let state_blue_red_user       = null;
let state_blue_red_corr       = null;
let selected_answer           = -1;
let firstTimer                = null;
let state_count_time_test     = null; // time of all test for every question
let state_count_time_question = null; // time for every question
let state_test                = null;
let WHY_botton_visibility     = null;
let setBlueVisibility         = null; //set blue color for active questions
let numberLevel               = null;

export function ShowCurrentTest(){   //show current test --------------------------------------------------------

//console.log('ShowCurrentTest: +++++++++++++');  
//console.log('ShowCurrentTest: props.currentTestFromHead=',props.currentTestFromHead);  

  // handleChange - choosing an answer for the question  ---------------------------------------------
  function handleChange(evt){  //evt.par1 - number of the current question; evt.par2 - selected answer.
//console.log('handleChange: +++++++++++++'); 
//console.log('0 ShowCurrentTest: handleChange:  countDownDate_qst=',countDownDate_qst);  
//console.log('ShowCurrentTest: handleChange:  evt=',evt);  
//console.log('1 ShowCurrentTest: handleChange:  state_test=',state_test); 
    if(evt.par1 === current_question){
        firstTimer = evt.par4;
        X_setInterval = evt.par3;

        let selected_answer = -1;
//        let arr_state_test_new = null;
//        let arr_state_blue_red _new = null; // = [user answer, correct answer]     
        let li_number = null; //selected answer  in the array   

        if(state_test[evt.par1] === true) state_test[evt.par1] = false;            
//console.log('1 ShowCurrentTest: handleChange:  state_test=',state_test);         

        if(state_test[evt.par1] === false) {
//          arr_state_test_new = state_test.slice();
//          arr_state_blue_red _new = state_blue_red .slice(); // = [user answer, correct answer]     
          li_number = evt.par2 - 1; //selected answer  in the array
          
          current_question = evt.par1;    // number of the current question
    
          selected_answer = li_number; //selected answer in the array of answers
    
          let id_input = "id" + String(current_question*10 + li_number);
          correct_answer = Number(tests[currentTest][current_question].C_A) - 1; 
          state_blue_red_user[current_question] = li_number;
          state_blue_red_corr[current_question] = correct_answer;
//console.log('ShowCurrentTest: handleChange:  correct_answer=',correct_answer, '  selected_answer=',selected_answer);                 
          let id_correct =  "id" + String(current_question*10 + correct_answer);//(correct_answer - 1));
    
          if(id_input === id_correct){
            count_correct_answer[current_question] = count_correct_answer[current_question] + 1; 	
          }
    
//console.log('1 ShowCurrentTest: handleChange:  before clearInterval: X_setInterval=',X_setInterval);                 
//          clearInterval(X_setInterval);       
//console.log('1 ShowCurrentTest: handleChange:  after clearInterval: X_setInterval=',X_setInterval);                           

//          firstTimer = true; //null;

//          countDownDate_qst   = new Date().getTime(); // start time for the chose question      
                    
//          current_question++; // go next question
//console.log('1_1 ShowCurrentTest: handleChange:  current_questionl=',current_question, ' count_questions_test=',count_questions_test);                           
          if(current_question < count_questions_test) {
            let ID_work = 'ID'+ current_question + currentTest*100 + '_time_test';
            let ID_next = ('ID'+ (current_question + 1)) + currentTest*100 +  '_time_question';
//            state_test[current_question] = false;
//console.log('1 ShowCurrentTest: handleChange: before startWatch4:  X_setInterval=',X_setInterval);  

//            startWatch4(ID_next, ID_work, current_question, firstTimer, countDownDate_qst, X_setInterval); // start time for next question
          }//if
          else {
//            firstTimer = true;
//console.log('1_2 ShowCurrentTest: handleChange:  current_questionl=',current_question, ' count_questions_test=',count_questions_test);                                       
          }  

//console.log('2 ShowCurrentTest: handleChange: after startWatch4: X_setInterval=',X_setInterval);                 
        }// if
//console.log('2 ShowCurrentTest: handleChange:  state_test=',state_test);
    }//if
//console.log('2 ShowCurrentTest: ************** handleChange:  firstTimer=',firstTimer);    
//console.log('2 ShowCurrentTest: ************** handleChange:  firstTimer=',firstTimer); 
        dispatch({type: 'ShowCurrentTest_handleChange',  
            payload: {
                state_blue_red_user:  state_blue_red_user, 
                state_blue_red_corr:  state_blue_red_corr,
                state_test:           state_test,
                current_question:     current_question,
                selected_answer:      selected_answer,
                count_correct_answer: count_correct_answer
            }
        }); 

  } //--- end handleChange --------------------------------------------------------------       
    
  async function timerTest(current_question, firstTimer, countDownDate_qst, X_setInterval) {  //----------------------------------
//console.log('HeaderSection2Test startWatch4: +++++++++');
    function sumMinSec(count_time_test_work, count_time_quest) {  //-------------
      //console.log('3 HeaderSection2Test startWatch4: sumMinSec: count_time_test_work=',count_time_test_work);           
      let pos=-1, minutes=0, seconds=0;

      pos = count_time_quest.indexOf(':');

      if (pos > 0) {
      minutes = Number(count_time_quest.slice(0, pos));
      seconds = Number(count_time_quest.slice(pos+1));
      } else {
      minutes = 0;
      seconds = 0;
      }

      pos = count_time_test_work.indexOf(':');
      if (pos > 0) {
      minutes += Number(count_time_test_work.slice(0, pos));
      seconds += Number(count_time_test_work.slice(pos+1));
      } 

      if (seconds >= 60) {
      minutes += Math.floor(seconds / 60);
      seconds = seconds - (Math.floor(seconds / 60) * 60);
      }

      if (minutes < 10) {
      minutes = '0' + minutes;
      }

      if (seconds < 10) {
      seconds = '0' + seconds;
      }
      return minutes + ':' + seconds;
              
    } //--- end of sumMinSec  --------------------------------------------
        //console.log('3 HeaderSection2Test startWatch4:  current_question=',current_question);  
        //console.log('3 HeaderSection2Test startWatch4:  firstTimer=',firstTimer);  
//console.log('3 HeaderSection2Test startWatch4:  countDownDate_qst=',countDownDate_qst);  
        //console.log('3 HeaderSection2Test startWatch4:  X_setInterval=',X_setInterval);  
        
        // sumMinSec - sum minutes and seconds of all test; return -  minutes:seconds              

    let now;
    let distance;
    let minutes;
    let seconds;

//console.log('0 HeaderSection2Test startWatch4: count_time_test=',count_time_test, '  current_question=',current_question, '  firstTimer=',firstTimer);    
//console.log('3_2 HeaderSection2Test startWatch4:  countDownDate_qst=',countDownDate_qst);  

    if(firstTimer === null) {//================================= start timer             

//console.log('3_3 HeaderSection2Test startWatch4:  countDownDate_qst=',countDownDate_qst);  
        
        countDownDate_qst = new Date().getTime() // start time for the choosing test

//     await new Promise((resolve,reject) => 
//      {
          X_setInterval = setInterval(function() { //++++++++++++++++++++++++++
//console.log('HeaderSection2Test startWatch4: setInterval: >>>>>>>>>>>>>>, current_question=', current_question)              
//console.log('3_3_3 HeaderSection2Test startWatch4:  countDownDate_qst=',countDownDate_qst);  
              // Get today's date and time
                  now = new Date().getTime();
          
              // Find the distance between now and the count down date
                  distance = now - countDownDate_qst;
      
                  minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                  seconds = Math.floor((distance % (1000 * 60)) / 1000);
          
                  if (minutes < 10) {
                  minutes = '0' + minutes;
                  }
                  if (seconds < 10) {
                  seconds = '0' + seconds;
                  }  
          
      //              count_time_question[0] = minutes + ":" + seconds;
                  count_time_test = minutes + ":" + seconds;
//console.log('2 HeaderSection2Test 1 count_time_test=',count_time_test);              
      
              
//console.log('HeaderSection2Test startWatch4:  distance=',distance)
      
                  if(distance < 0) {
                  clearInterval(X_setInterval);       
                  }
              
      //              count_time_test = count_time_question[0];
      //console.log('3 HeaderSection2Test 0 count_time_test[0]=',count_time_test[0]);                         
                  count_time_test = sumMinSec(count_time_test,'00:01');  
//console.log('3 HeaderSection2Test 2 count_time_test=',count_time_test);             
                  //console.log('4 HeaderSection2Test 1 count_time_question=',count_time_question); 
                  //console.log('HeaderSection2Test startWatch4:  X_setInterval=',X_setInterval);  
//                  resolve(                        
                    dispatch({type: 'HeaderSection2Test_count_time_test', 
                        payload: {          
                            count_time_test:    count_time_test,
                            X_setInterval:      X_setInterval 
                        }
                    })
//                  );  
          
              }, 1000);// end of  X_setInterval = setInterval(function() ++++++++++++++++++++++++++
//        })//timerPromise
           
//console.log('end promise====================================================');

    }//if =================================================================================             

  }// end of timerTest ----------------------------
  


  let ID_time; // ID for time_test

  let ID_time_qst; // ID for time_tests_qst

  let ID_work;

  let element;

  let opacity_val     = null;

  let firstFraseWork  = null;

  let levelTest       = null;

  let showResults     = null;

  let scoreTest       = 0;

  let arr_val         = null;

  let ii = null;

  
  let dispatch = useDispatch();   


  currentTest           = useSelector((store) => store.currentTest);
  correct_answer        = useSelector((store) => store.correct_answer);
  tests                 = useSelector((store) => store.tests);   
  countDownDate         = useSelector((store) => store.countDownDate);
  countDownDate_qst     = useSelector((store) => store.countDownDate_qst);
  X_setInterval         = useSelector((store) => store.X_setInterval);
  current_question      = useSelector((store) => store.current_question);
  count_questions_test  = useSelector((store) => store.count_questions_test); //the count of questions in the test
  count_time_question   = (useSelector((store) => store.count_time_question)).slice();
  count_time_test       = (useSelector((store) => store.count_time_test)).slice();
  firstTimer            = useSelector((store) => store.firstTimer); // firstTimer = null (start timer), firstTimer = true (stop timer)
  state_test            = useSelector((store) => store.state_test);
  state_blue_red_user   = useSelector((store) => store.state_blue_red_user ) ;//).slice();
  state_blue_red_corr   = useSelector((store) => store.state_blue_red_corr ) ;//).slice();
  WHY_botton_visibility = useSelector((store) => store.WHY_botton_visibility);
  setBlueVisibility     = useSelector((store) => store.setBlueVisibility);
  numberLevel           = useSelector((store) => store.numberLevel);
  showResults           = useSelector((store) => store.showResults);
  count_correct_answer  = useSelector((store) => store.count_correct_answer);


  setBlueVisibility = Array(count_questions_test).fill('no_li_class');// it is the class with yellow color (cover pointer)
  setBlueVisibility[current_question] = 'li_class pointer';


//    let nameCurrentTest     = "TEST " + currentTest; 
  let first_frase = <div id='chooseSentence'> 
    Choose the correct option for each sentence
  </div> 

//console.log('ShowCurrentTest:  $$$$$$$$$$$$$$$$$$$$$$ currentTest=',currentTest, ' count_questions_test=',count_questions_test); 

//    for(let ii=0; ii < count_questions_test; ii++) { // show all questions for the test
  ii = current_question;
  if(ii > 0) first_frase = null;
  ID_work = 'ID'+ ii + currentTest*100 +  '_question_cont';  
//        if (current_question === ii) opacity_val = {opacity: 1} //current question
//        else opacity_val = {opacity: 0.5};
  if(state_test[count_questions_test-1] === false) {
    opacity_val = {opacity: 1}; //end of choosing all answers
  }

  
  if(showResults) {
    // count correct answers ---
    arr_val = tests[currentTest]; // data  of the current test    
    count_correct_answer.forEach((el, i) => {
      if ( el === (arr_val[i].C_A - 1) ) scoreTest++; 
    });
    first_frase = (
      <div id='countCorrectAnswers'> 
        Your score is {scoreTest} out of {count_questions_test}
        <div id='testLevel'>
          TEST {currentTest} level {numberLevel}
        </div>
      </div> 
    )  
  }
  else {
    first_frase = (
      <div id='chooseSentence'> 
        Choose the correct option for each sentence
      </div> 
    )
  }

//console.log('2 ShowCurrentTest:   showResults=',showResults);          
//console.log('first_frase=',first_frase);          

  element = (
    <div id='oneTest'>
      <div key={ID_work} id={ID_work} className="question_cont" style={opacity_val}>
        {first_frase}
        <QuestionTest numberQuestion={ii} />
        <AnswerTest numberQuestion={ii} classLi={setBlueVisibility[ii]} func={(e) => handleChange(e)} />
        <FooterQuestionTest numberQuestion={ii} />
      </div>
    </div>
  )

  return element;

} //--- end of ShowCurrentTest -----------------------------------------------------