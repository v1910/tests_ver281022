//HeaderSection2Test.js - header of Section 2 of Tests

import { useSelector, useDispatch }   from 'react-redux';

import  "./HeaderSection2Test.css";

import questionGroup_330   from "./group_330.svg"; //question symbol
import timerGroup_435      from "./group_435.svg"; //timer symbol


/*html text for section 2 of the main page */
export function HeaderSection2Test() {
//console.log('HeaderSection2Test-------------------')  

    function sumMinSec(count_time_test_work, count_time_quest) {  //-------------
        //console.log('3 HeaderSection2Test startWatch4: sumMinSec: count_time_test_work=',count_time_test_work);           
        let pos=-1, minutes=0, seconds=0;

        pos = count_time_quest.indexOf(':');

        if (pos > 0) {
        minutes = Number(count_time_quest.slice(0, pos));
        seconds = Number(count_time_quest.slice(pos+1));
        } else {
        minutes = 0;
        seconds = 0;
        }

        pos = count_time_test_work.indexOf(':');
        if (pos > 0) {
        minutes += Number(count_time_test_work.slice(0, pos));
        seconds += Number(count_time_test_work.slice(pos+1));
        } 

        if (seconds >= 60) {
        minutes += Math.floor(seconds / 60);
        seconds = seconds - (Math.floor(seconds / 60) * 60);
        }

        if (minutes < 10) {
        minutes = '0' + minutes;
        }

        if (seconds < 10) {
        seconds = '0' + seconds;
        }
        return minutes + ':' + seconds;
                
    } //--- end of sumMinSec  --------------------------------------------


    async function testTimer(){
        let now;
        let distance
        let minutes;
        let seconds;
        let counterWork;
               
        countDownDate_qst = new Date().getTime(); // start time for the choosing test

        X_setInterval = setInterval(() => {
            now = new Date().getTime();
            // Find the distance between now and the count down date
            distance = now - countDownDate_qst;
            minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            seconds = Math.floor((distance % (1000 * 60)) / 1000);
            if (minutes < 10) {
            minutes = '0' + minutes;
            }
            if (seconds < 10) {
                seconds = '0' + seconds;
            }            
            counterWork = minutes + ":" + seconds;
    
            if(distance < 0) {
            return clearInterval(X_setInterval);       
            }
            
            count_time_test = sumMinSec(counterWork,'00:01');  
        
            dispatch({type: 'HeaderSection2Test_count_time_test', 
                payload: {          
                    count_time_test:    count_time_test,
                    X_setInterval:      X_setInterval,
                    activeTest:         activeTest,
                    countDownDate_qst:  countDownDate_qst
                }
            }) 
        }, 1000)                                       

    }//end of testTimer -------------------------------


    let boxCount                  = null; //count of timer boxes
    let widthTimerBox             = null; //width of timer box
    let count_time_test           = null;
    let current_question          = null;
    let count_questions_test      = null;
    let width_id_sliderHeaderTest = null;
    let X_setInterval             = null;    
    let countDownDate_qst         = null;
    let activeTest                = null;  
    let showResults               = null;  
    
    
    let dispatch = useDispatch();  

    current_question          = useSelector((store) => store.current_question);
    count_questions_test      = useSelector((store) => store.count_questions_test);// all questions
    count_time_test           = useSelector((store) => store.count_time_test);// all time of test
    width_id_sliderHeaderTest = useSelector((store) => store.width_id_sliderHeaderTest);// width od id=sliderHeaderTest
    X_setInterval             = useSelector((store) => store.X_setInterval);
    countDownDate_qst         = useSelector((store) => store.countDownDate_qst);
    activeTest                = useSelector((store) => store.activeTest);
    showResults               = useSelector((store) => store.showResults);   
    
    //width of header box -------
    let win = window,
    doc = document,
    docElem = doc.documentElement,
    elem = document.getElementById('sliderHeaderTest'),
    x = win.innerWidth || docElem.clientWidth || elem.clientWidth;

    if(x < 1000) width_id_sliderHeaderTest = 100; //170;

    if(count_questions_test > 0){
        boxCount = Math.floor(width_id_sliderHeaderTest/count_questions_test);
        widthTimerBox = width_id_sliderHeaderTest/count_questions_test + 'px';
    }
    else {
        boxCount = 1;
        widthTimerBox = '1px';
        console.log('Error of the Site: count_questions_test is underfined in HeaderSection2Test.js');
    }    

    let widthBox = {width: widthTimerBox};
    let arr = new Array(boxCount);

    if ( showResults ) {
        current_question = count_questions_test - 1;
    }

    for(let i=0; i < current_question+1; i++) {
        arr[i] = <div id='oneBoxTimer' style={widthBox}></div>
    }   
    
 

    if (activeTest) {
        activeTest = false;
        testTimer();
    } 
    
    return (
        <div id='contHeaderTest'>
            <hr id='headerUpLine'/>
            <div id='headerTestCont'>
                <div>
                    <img id='imgHeaderTestQuestionTimerLeft' src={questionGroup_330} />
                </div>
                <div className="textHeadTestQuestion">
                    Question {current_question + 1} of {count_questions_test}
                </div> 
                <div id='sliderHeaderTest'>
                    <>
                        {arr}
                    </>
                </div>
                <div>
                    <img id='imgHeaderTestQuestionTimerRight' src={timerGroup_435} />
                </div>
                <div id="textHeaderTestTime">
                    Time: {count_time_test} 
                </div> 
            </div>
            <hr id='headerUpLine'/>
        </div>
    ) 

}// end of Section2MainPage()