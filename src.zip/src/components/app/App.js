//App.js- main program -----------------

import React from 'react';

import {Header} from '../header/Header.js'; //all site

import {Init}  from "../init/Init.js"; //init data for 3 sections of the home page

import {MenuMainPage}          from "../menuMainPage/MenuMainPage.js"; //init data for the menu of the home page

import './App.css';


let init = null;

function App() {
console.log("App: -----------------"); 
  init = Init();

  return (
    <div id="contSite_R195" >  
      < MenuMainPage />   
      < Header />
    </div>    
  )

}
export default App;
