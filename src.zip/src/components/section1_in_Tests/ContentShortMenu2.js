//ContentShortMenu.js - Content of Short Menu of main page

import React          from "react";
import { useSelector } from 'react-redux';


/* short menu*/
export function ContentShortMenu2(){

  let visibContentShortMenu    = useSelector((store) => store.visibContentShortMenu); 
  
  return null;
    
} // end of contentShortMenu() ---