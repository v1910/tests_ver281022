//Init.js- Initializetion of data of  Home Page --------------------------

import { useSelector, useDispatch } from 'react-redux';


// init data for 3 sections  of the home page 
export function Init() {//=============================================

console.log('Init.js----')  

  let currentPhrasesServer   = null;

  let textSection1LeftTest   = null;

  let currentPhrases         = useSelector((store) => store.currentPhrases); 

  let currentTest            = useSelector((store) => store.currentTest); 

  let numberLevel            = useSelector((store) => store.numberLevel); 

  let current_question_plus1 = useSelector((store) => store.current_question_plus1s); 

  let imgSection1RightTest   = useSelector((store) => store.imgSection1RightTest); 
  
//  
  let dispatch = useDispatch();

  // reading phrases from DB -------------------
  if(currentPhrases !== null) {
    currentPhrasesServer = '/get' + currentPhrases;
  } else currentPhrasesServer = '/home';
  //console.log('Phrases: currentPhrasesServer=', currentPhrasesServer);

  const axios = require('axios');

  async function makeGetRequest() {

    let res = await axios.get(currentPhrasesServer);

    let data = res.data;
  //console.log('Phrases: currentPhrasesServer data=', data);

    dispatch({type: 'ShowCurrentPhrases', payload: { phrases: data } })
    
  }// async ---------------------------------



  return null;

} // end of Init=============================================

