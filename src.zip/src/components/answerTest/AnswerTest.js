//AnswerTest-------- Form answer variants for one test question

import React, { useEffect } from "react"

import { useSelector, useDispatch } from 'react-redux';

import './AnswerTest.css';


let selected_answer       = null;
let state_blue_red_user   = null;
let state_blue_red_corr   = null;
let answerSymbol          = null;
let showResults           = null;
let count_correct_answer  = null;
let tests                 = null;
let arr_val               = null;
let currentTest           = null;
//let X_setInterval         = null;
//let firstTimer            = null;

//let workAnswerSymbol = [];


export function AnswerTest(props)  {  //-------------------------------------------------------------------
//console.log('AnswerTest: --------------');                
//console.log('AnswerTest:  props.classLi=',props.classLi);              
  
  function onClickAnswerTest(i_ans) { //onClick in AnswerTest, i_ans - number of clicking answer
//console.log('onClickAnswerTest ===============================+++++&&&&&&&&&&&&&&&&&& i_ans= ',i_ans);   

    if(!showResults) {

      for(let k=0; k < li_style.length; k++) {
        li_style[k] = {backgroundColor:  "rgba(255,255,255,1)"}; //white
        answerSymbol = [...workAnswerSymbolBlue];
      }
      
      li_style[i_ans]     = {backgroundColor: "rgba(59,179,189,1)", color: 'white'}; // blue
      answerSymbol[i_ans] = workAnswerSymbolWhite[i_ans];
  //    state_blue_red[current_question][0] = i_ans;
  //      work_state_blue_red[current_question][0] = i_ans;
          state_blue_red_user[current_question] = i_ans;
  //console.log('onClickAnswerTest =====+++++&&&&&&&&&&&&&&&&&& - state_blue_red_user[current_question]= ',state_blue_red_user[current_question]);      
      

      answerSymbol = [...workAnswerSymbolBlue];

      answerSymbol[i_ans] = workAnswerSymbolWhite[i_ans];

  //    for(let p=0; p<20; p++){
  //      console.log('$$$$$$$$$$$$$$$$ p  state_blue_red_user[p]=',p, ' ', state_blue_red_user[p]);
  //      console.log('$$$$$$$$$$$$ p  current_question=',p, ' ', current_question);      
  //    }

      count_correct_answer[current_question] = i_ans;  

      styleNext = {display: 'block'};

      selected_answer =  i_ans;

    }//if
    dispatch({type: 'AnswerTest_state_blue_red',  
      payload: {
        state_blue_red_user:   state_blue_red_user,
        state_blue_red_corr:   state_blue_red_corr,
        count_correct_answer:  count_correct_answer,
        styleNext:             styleNext,
        selected_answer:       selected_answer
      }
    }); 

  }// end of onClickAnswerTest ----

  function blueVisibility(par,e) { // onMouseEnter  ---------------------------------

    if(!showResults) {

//      e.target.style.background = "#ADD8E6";  //light blue
      e.target.style.boxShadow = "10px 10px 5px #ADD8E6";
//      e.target.style.color      = "white"; 
    }

  } //--- end of  blueVisibility--------------------------------------------------

  function whiteVisibility(par,e) {  // onMouseLeave--------------------------------------

  if(!showResults) { 

    if( count_correct_answer[current_question] !== par ) {
//      e.target.style.background = "white";  
//      e.target.style.color      = "#3BB3BD";  //blue  
      e.target.style.boxShadow = "none";
    } 
  }

}  //--- end of whiteVisibility------------------------------------------------------------


  //form li list for counter
  function answer_li(counter){
//console.log('answer_li: --------------');                
    let work_li = [];
    let idCorrectAnswer;
    let commentStyle;

    for(let i=0; i<=counter-4; i++){  
      if (currQuestProps[i].commentDisplay === 'none') {
        commentStyle = {display: 'none'};
      } else {
        commentStyle = {display: 'block', color: currQuestProps[i].commentColor};
      }
//console.log('commentStyle=',commentStyle);         
      idCorrectAnswer = 'correctAnswer' + (current_question*10 + i);//{{commentStyle}}
      work_li[i] = (
      <>
        <div id={idCorrectAnswer} className='classCorrectAnswer' style={commentStyle}>{currQuestProps[i].commentTxt}</div>
        <div key={ID_li[i]} id={ID_li[i]} className={props.classLi}   
          style={li_style[i]} 
          onClick={() => onClickAnswerTest(i)} 
          onMouseEnter={(e) => blueVisibility(i,e)} 
          onMouseLeave={(e) => whiteVisibility(i,e)} >
          <img id={'img' + (current_question*10 + i)}  className='imgAnswerTest' src={currQuestProps[i].answerImg} />
          <div id={'txt' + (current_question*10 + i)} className="contentOneAnswer">{li_text[i]}</div>
        </div>
      </>
      )
//        <div id={idCorrectAnswer} className='classCorrectAnswer' style={{color: currQuestProps[i].commentColor}}>{currQuestProps[i].commentTxt}</div>
//console.log('answer_li: li_text[i] , i = ', li_text[i], ' ', i); 
    }//for

    return <>{work_li}</>;
  }//end of answer_li------


  let workAnswerSymbolBlue    = null;
  let workAnswerSymbolWhite   = null;
  let workAnswerSymbolRed     = null;
  let current_question        = null;
  let styleNext               = null;
  let currQuestProps          = [];
  
  let dispatch = useDispatch();   


    currentTest             = useSelector((store) => store.currentTest); 
    current_question        = useSelector((store) => store.current_question); 
    state_blue_red_user     = (useSelector((store) => Array.from(store.state_blue_red_user ))); //state of every line of answers
    selected_answer         = useSelector((store) => store.selected_answer);
    showResults             = useSelector((store) => store.showResults);
    count_correct_answer    = useSelector((store) => store.count_correct_answer);    
    currentTest             = useSelector((store) => store.currentTest);
    workAnswerSymbolBlue    = useSelector((store) => store.workAnswerSymbolBlue);
    workAnswerSymbolWhite   = useSelector((store) => store.workAnswerSymbolWhite);
    workAnswerSymbolRed     = useSelector((store) => store.workAnswerSymbolRed);
    styleNext               = useSelector((store) => store.styleNext); 
    currQuestProps          = useSelector((store) => store.currQuestProps); 
    state_blue_red_corr     = useSelector((store) => store.state_blue_red_corr);  
    tests                   = useSelector((store) => store.tests);// read all tests   
    
    
    answerSymbol = [...workAnswerSymbolBlue];

    arr_val = tests[currentTest][current_question];


    if(state_blue_red_user[current_question] !== -1) 
      answerSymbol[state_blue_red_user[current_question]] = workAnswerSymbolWhite[state_blue_red_user[current_question]];

//console.log('AnswerTest:  current_question=',current_question);
//console.log('AnswerTest:  currentTest=',currentTest)

    let ID_li                 = [];
    let j;
    let li_text               = [];
    let counter               = 0; // count of rows in the current question
    let li_key;
    let li_style              = [];  // style of li
    let correct_answer        = null;
   
    for (let key in arr_val) {
      counter++; //count of lines in a question (question, number correct answer, answers)
    }


    correct_answer = arr_val['C_A'] - 1;

//console.log('AnswerTest:  currQuestProps=',currQuestProps);
//console.log('AnswerTest:  counter=',counter);

    for(let i=3; i < counter; i++){
      j = i - 3;    
      ID_li[j] = "id" + (current_question*10 + j);
      li_key = "A" + (i-2);
      li_text[j] = arr_val[li_key];// answers list
      if((state_blue_red_user[current_question] !== -1) && ( j === state_blue_red_user[current_question] ) ){
        li_style[j] = {backgroundColor: "rgba(59,179,189,1)", color: 'white'}; // blue 
      } else {
        li_style[j] = {backgroundColor:  "rgba(255,255,255,1)"}; //white        
      }
      if(showResults) { //it has been to show results
        li_style[j] = {backgroundColor:  currQuestProps[j].answerBackgroundColor, color: currQuestProps[j].answerColor};
      }
//console.log('AnswerTest:  workAnswerSymbolWhite[j]=',workAnswerSymbolWhite[j]);      
      // init currQuestProps
      if ( !showResults ) {
        currQuestProps[j] = {
          answerBackgroundColor: "rgba(59,179,189,1)",
          answerImg: workAnswerSymbolWhite[j],
          answerColor: '#3BB3BD',
          commentColor: '#3BB3BD',
          commentTxt: '',
          commentDisplay: 'none'
        }    
      }
//console.log('AnswerTest:  currQuestProps[j].commentDisplay =', currQuestProps[j].commentDisplay); 
    } // for   

    return answer_li(counter);

} // --- end of AnswerTest ---
