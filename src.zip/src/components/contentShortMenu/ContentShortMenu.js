//ContentShortMenu.js - Content of Short Menu of main page

import React                        from "react";

import { useSelector, useDispatch } from 'react-redux';

import { HeaderSection2Test }       from "../headerSection2Test/HeaderSection2Test";

import backArrowBlue                from "./BackArrowBlue.svg";

import shortMenuOnOut               from "../menuMainPage/Group_466.svg"; //file for showing the short main menu

import closeShortMenu               from "../menuMainPage/Group1011.svg"; //file for closing the short main menu

import group422                     from "./Group422.svg";

import  "./ContentShortMenu.css";


let visibContentShortMenu     = null;
let current_question          = null;
let imgShortMenuFile          = null;//show Group305.svg, otherwise Group1011.svg (false)
let iconShortMenu             = null; // = shortMenuOnOut or closeShortMenu
let imgSection1Right          = null;
let textSection1Left          = null;
let currentTest               = null;
let count_time_test           = null;
let count_questions_test      = null;
let width_id_sliderHeaderTest = null;
let current_question_plus1    = null;
let headerSection2Test        = null;
let state_blue_red_user       = null;
let state_blue_red_corr       = null;
let showNoneImgShortMenuFile  = null;
let numberLevel               = null;
let X_setInterval             = null;

/* short menu*/
export function ContentShortMenu(){
//console.log('ContentShortMenu-------------------')

    // write number (par-1) of current test
    function onClickTest(numberTest, numberLevel) {
//console.log('onClickTest from ContentShortMenu: numberTest=',numberTest);
      currentTest = numberTest-1;
      current_question = 0;
      current_question_plus1 = 1;

      clearInterval(X_setInterval);


      dispatch({ type: 'MenuMainPage_onClickTest', payload: 
          {   
            currentTest:            currentTest,
            currentBranchSite:      'Tests',
            initSection3HomePage:   null,
            numberLevel:            numberLevel,
            current_question:       current_question,
            current_question_plus1: current_question_plus1,
            countDownDate_qst:      new Date().getTime(), // start time for the choosing test
            activeTest:             true
          }
      });

      dispatch({type: 'MenuMainPage_Init', 
        payload: {
            state_blue_red_user:  Array(count_questions_test).fill(-1),// user answer ,
            state_blue_red_corr:  Array(count_questions_test).fill(-1),// correct answer 
            count_time_test:      '00:00', // all time for the current test
            count_time_question:  Array(count_questions_test).fill('00:00'),  // all time for the current question
            countDownDate:        new Date().getTime(), // start time for the chosing test
            firstTimer:           null,
            count_questions_test: count_questions_test
        }
      })
//console.log('onClickTest from ContentShortMenu: numberLevel=',numberLevel);
//      work = OnClickTestSection1(numberTest, numberLevel, current_question); //return:  work[0]= imgSection1Right, work[1]=textSection1Left
//      work = OnClickTestSection1(); //return:  work[0]= imgSection1Right, work[1]=textSection1Left

      imgSection1Right = 
      <div id='contImgTest'>
        <img  id='imgGroup411Head' src={group422} />
      </div> 

      textSection1Left = 
      <div className='contTitleTextTest'>           
        <div id='titleTextSection1Tests'>
            Home > TEST {numberTest}, level {numberLevel} > <span id='titleTextSection1TestsQuestion'>Question {current_question_plus1}</span> 
        </div> 
        <div>
            Welcome to the English level tests!
        </div>  
      </div> 


      dispatch({type: 'InitSection1HomePage', 
          payload: {
              imgSection1Right: imgSection1Right,
              textSection1Left: textSection1Left
          }
      })
//console.log('ContentShortMenu: textSection1Left=',textSection1Left);

      dispatch({  type: 'contShortMenu', 
      payload:    {visibContentShortMenu:{display: 'none'},
                  imgShortMenuFile:      !imgShortMenuFile,
                  iconShortMenu:         (iconShortMenu === shortMenuOnOut) ? closeShortMenu : shortMenuOnOut
                  }
      })
          
        // section 2 of a test----------------
      headerSection2Test = HeaderSection2Test(currentTest,numberLevel, current_question, count_questions_test, count_time_test, width_id_sliderHeaderTest);
     
      dispatch({type: 'headerSection2Test', payload: {headerSection2Test: headerSection2Test } });

  }// end of onClickTest---------------

  if(imgShortMenuFile !== true) {
    showNoneImgShortMenuFile = {display: 'none'};
  } else {

    showNoneImgShortMenuFile = {display: 'block'}; 
  } 

  let dispatch  = useDispatch();

  count_questions_test      = useSelector((store) => store.count_questions_test); 
  count_time_test           = useSelector((store) => store.count_time_test);    
  currentTest               = useSelector((store) => store.currentTest); 
  numberLevel               = useSelector((store) => store.numberLevel);
  visibContentShortMenu     = useSelector((store) => store.visibContentShortMenu); 
  current_question          = useSelector((store) => store.current_question);
  imgShortMenuFile          = useSelector((store) => store.imgShortMenuFile); //show Group305.svg, otherwise Group1011.svg (false)  
  iconShortMenu             = useSelector((store) => store.iconShortMenu);     
  width_id_sliderHeaderTest = useSelector((store) => store.width_id_sliderHeaderTest);// width od id=sliderHeaderTest  
  X_setInterval             = useSelector((store) => store.X_setInterval); 

//console.log('ContentShortMenu: visibContentShortMenu=',visibContentShortMenu);

  return( // it's the big menu
    <div id='contShortMenu' style={visibContentShortMenu}>
      <ul>
        <li><a href='#'>Tests <img src={backArrowBlue} /></a>
          <ul id='contMenuTest'>
            <li><a href="#" onClick={()=>onClickTest(1, 'B2')}>Test1 (B2)</a></li>
            <li><a href="#" onClick={()=>onClickTest(2, 'B2')}>Test2 (B2)</a></li>
            <li><a href="#" onClick={()=>onClickTest(3, 'B1')}>Test3 (B1)</a></li>
            <li><a href="#" onClick={()=>onClickTest(4, 'B1')}>Test4 (B1)</a></li>
            <li><a href="#" onClick={()=>onClickTest(5, 'B1')}>Test5 (B1)</a></li>
          </ul>
        </li>
        <li><a href='#'>Words <img src={backArrowBlue} /></a>
          <ul>
            <li><a href="#">Society</a></li>
            <li><a href="#">Sport</a></li>
            <li><a href="#">Accommodation</a></li>
            <li><a href="#">Appearance</a></li>
            <li><a href="#">Prepositions</a></li>
            <li><a href="#">Nature</a></li>                
          </ul>            
        </li>
        <li><a href='#'>Listen <img src={backArrowBlue} /></a>
          <ul>
            <li><a href="#">Story1</a></li>
            <li><a href="#">Story2</a></li>
            <li><a href="#">Story3</a></li>
            <li><a href="#">Story4</a></li>
          </ul>            
        </li>
        <li><a href='#'>Phrases <img src={backArrowBlue} /></a>
          <ul>
            <li><a href="#">Greatings</a></li>
            <li><a href="#">Phrasalverbs</a></li>
            <li><a href="#">Presentation</a></li>
            <li><a href="#">Spring</a></li>
          </ul>            
        </li>
        <li><a href='#'>Jokes</a></li>
        <li><a href='#'>Statistics</a></li>
      </ul>
      <div id='loginButton'>Login</div>      
    </div>
    );

} // end of contentShortMenu() ---