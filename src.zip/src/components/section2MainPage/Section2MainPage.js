//Section2MainPage.js - init data  of Section2 of MainPage

import React              from "react";

import { useSelector }    from 'react-redux';


import {ShowCurrentTest}  from "../showCurrentTest/ShowCurrentTest.js"; // Show Current Test
import {HeaderSection2Test}  from "../headerSection2Test/HeaderSection2Test.js"; // Show Current Test


let currentBranchSite         = null;
let initSection2HomePage      = null;
let headerSection2Test        = null;

/*html text for section 2 of the main page */
export function Section2MainPage() {
//console.log('Section2MainPage------------------')

  currentBranchSite         = useSelector((store) => store.currentBranchSite);

  initSection2HomePage      = useSelector((store) => store.initSection2HomePage);

//console.log('initSection2HomePage=',initSection2HomePage)

//  headerSection2Test = HeaderSection2Test();


  return (
    currentBranchSite === 'Home' ?
      initSection2HomePage
    : currentBranchSite === 'Tests' ?
      <section id='section2MainPage'>
          <HeaderSection2Test />
          <ShowCurrentTest />
      </section>
      : <></>
  )
    
}// end of Section2MainPage() ------
