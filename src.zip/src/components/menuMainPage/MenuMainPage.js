// MenuMainPage.js - main menu of the site (Header.js includes MenuMainPage.js)
 
import React from "react";

import { useSelector, useDispatch } from 'react-redux';

import  "./MenuMainPage.css";

import {ContentShortMenu}     from "../contentShortMenu/ContentShortMenu.js"; //short menu

import logoTests                  from "./LogoGroup33.svg"; //site logo
import backArrowBlue              from "./BackArrowBlue.svg";
//import group422                   from "./Group422.svg";
import shortMenuOnOut             from "./Group_466.svg"; //file for showing the short main menu
import closeShortMenu             from "./Group1011.svg"; //file for closing the short main menu
//import { homedir } from "os";

let showNoneImgShortMenuFile  = null;
let visibContentShortMenu     = null;
let imgShortMenuFile          = null;//show Group305.svg, otherwise Group1011.svg (false)
let iconShortMenu             = null; // = shortMenuOnOut or closeShortMenu
let current_question          = null;
let current_question_plus1    = null;
let work                      = null;
let imgSection1Right          = null;
let textSection1Left          = null;
let imgSection1RightTest      = null;
let textSection1LeftTest      = null;
let headerSection2Test        = null;
let contentShortMenu          = null;
let currentTest               = null;
let count_time_test           = null;
let count_questions_test      = null;
let width_id_sliderHeaderTest = null;
let state_blue_red_user       = null; //user choice of answer
let state_blue_red_corr       = null; //correct answer
let state_count_time_test     = null; //state of count time test
let state_count_time_question = null; // state of count time question
let count_time_question       = null;
let workAllTest               = null;
let tests                     = null;
let X_setInterval             = null;
let count_correct_answer      = null;

/*html text for main menu - the big screen */
// screenSize - screen Size, tabletMaxScreenSize - Max Screen Size of tablet
export function MenuMainPage() {   
/*
//console.log('MenuMainPage---');

    function onClickHome() { // click on Home img

console.log('Home')
    }// end of onClickHome ---


    // write number (par-1) of current test
    function onClickTest(numberTest, numberLevel) {
console.log('onClickTest--------------');
        dispatch({ type: 'MenuMainPage_onClickTest', payload: 
            {   
                currentTest:            numberTest,
                numberLevel:            numberLevel,
            }
        });
    }// end of onClickTest---------------


    function onClickWord(nameSectionWord) {

    } // end of onClickWord


    let dispatch  = useDispatch();

    let menuMainPage = null;

    visibContentShortMenu     = useSelector((store) => store.visibContentShortMenu); 
    imgSection1RightTest      = useSelector((store) => store.imgSection1RightTest);     
    textSection1LeftTest      = useSelector((store) => store.textSection1LeftTest);     
    imgShortMenuFile          = useSelector((store) => store.imgShortMenuFile); //show Group305.svg, otherwise Group1011.svg (false)
    iconShortMenu             = useSelector((store) => store.iconShortMenu);     
    current_question          = useSelector((store) => store.current_question);
    current_question_plus1    = useSelector((store) => store.current_question_plus1);    
//    count_questions_test      = useSelector((store) => store.count_questions_test);// all questions
//    count_time_test           = useSelector((store) => store.count_time_test);// all time of test
    width_id_sliderHeaderTest = useSelector((store) => store.width_id_sliderHeaderTest);// width od id=sliderHeaderTest
    tests                     = useSelector((store) => store.tests);// read all tests
    X_setInterval             = useSelector((store) => store.X_setInterval);
    
    
//console.log('Header: workAllTest=',workAllTest);
  
    if(imgShortMenuFile !== true) {
      showNoneImgShortMenuFile = {display: 'none'};
    } else {

      showNoneImgShortMenuFile = {display: 'block'}; 
    }  

    contentShortMenu = ContentShortMenu(); // short menu

//console.log('screenSize=',screenSize);    
//console.log('tabletMaxScreenSize=',tabletMaxScreenSize);
//onClick={onClickHome()}
    menuMainPage =  // for a little screen
    <>
        <div id='contHeader_198'>
            <nav id='contMainMenu_235'>
            <p id='contLogo'><img src={logoTests}/></p>
            <div id='shortMenu'>
                <img id='imgShortMenu' 
                    onClick= {() => dispatch({  type: 'contShortMenu', 
                                payload:    {visibContentShortMenu: showNoneImgShortMenuFile,
                                            imgShortMenuFile:      !imgShortMenuFile,
                                            iconShortMenu:         (iconShortMenu === shortMenuOnOut) ? closeShortMenu : shortMenuOnOut
                                            }
                                            })
                            }       
                    src={iconShortMenu} />
            </div>
            <ContentShortMenu />
            </nav>        
        </div>
        <nav id='contMainMenu'>
            <p id='contLogo'><img src={logoTests}/></p>
            <ul>
            <li><a href='#'>Tests <img src={backArrowBlue} /></a>
                <ul id='contMenuTest'>
                <li onClick={()=>onClickTest(1, 'B2')}><a href='#'>Test1 (B2)</a></li>
                <li onClick={()=>onClickTest(2, 'B2')}><a href='#'>Test2 (B2)</a></li>
                <li onClick={()=>onClickTest(3, 'B1')}><a href="#">Test3 (B1)</a></li>
                <li onClick={()=>onClickTest(4, 'B1')}><a href="#">Test4 (B1)</a></li>
                <li onClick={()=>onClickTest(5, 'B1')}><a href="#">Test5 (B1)</a></li>
                </ul>
            </li>
            <li><a href='#'>Words <img src={backArrowBlue} /></a>
                <ul>
                <li onClick={()=>onClickWord('Society')}><a href="#">Society</a></li>
                <li onClick={()=>onClickWord('Sport')}><a href="#">Sport</a></li>
                <li onClick={()=>onClickWord('Accommodation')}><a href="#">Accommodation</a></li>
                <li onClick={()=>onClickWord('Appearance')}><a href="#">Appearance</a></li>
                <li onClick={()=>onClickWord('Prepositions')}><a href="#">Prepositions</a></li>
                <li onClick={()=>onClickWord('Nature')}><a href="#">Nature</a></li>                
                </ul>            
            </li>
            <li><a href='#'>Listen <img src={backArrowBlue} /></a>
                <ul id='contMenuTest'>
                <li><a href="#">Story1</a></li>
                <li><a href="#">Story2</a></li>
                <li><a href="#">Story3</a></li>
                <li><a href="#">Story4</a></li>
                </ul>            
            </li>
            <li><a href='#'>Phrases <img src={backArrowBlue} /></a>
                <ul id='contMenuTest'>
                <li><a href="#">Greatings</a></li>
                <li><a href="#">Phrasalverbs</a></li>
                <li><a href="#">Presentation</a></li>
                <li><a href="#">Spring</a></li>
                </ul>            
            </li>
            <li><a href='#'>Jokes</a></li>
            <li><a href='#'>Statistics</a></li>
            </ul>
            <p className='box' id='contLogin'><span id='contLoginText'>Login</span></p>
        </nav>    
    </>

    dispatch({ type: 'MenuMainPage_menuMainPage', payload: {menuMainPage: menuMainPage }});
*/
    return null;

} // end of MenuMainPage()