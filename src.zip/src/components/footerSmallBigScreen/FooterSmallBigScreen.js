//FooterSmallBigScreen.js - drop down menu for Footer of home page

import React          from "react";

import { useSelector, useDispatch } from 'react-redux';

import  "./FooterSmallBigScreen.css";


/* footer for small and big screen */
// screenSize - screen Size, tabletMaxScreenSize - Max Screen Size of tablet
export function FooterSmallBigScreen(){
   
    // write number (par-1) of current test
    function onClickTest(numberTest, numberLevel) {
        dispatch({ type: 'MenuMainPage_onClickTest', payload: 
            {   
                currentTest:            numberTest,
                numberLevel:            numberLevel
            }
        });
    }// end of onClickTest---------------            


    let work = null;

    let imgShortMenuFile = null;

    let testWork = (
        <div id='TestsFooterMenu'>
            <div id='TestsFooterMenuMain'>
            Tests
            </div>
            <div id='Test1FooterMenu' className='footerMenu' onClick={()=>onClickTest(1, 'B2')}>
            Test1 (B2)
            </div>
            <div id='Test2FooterMenu' className='footerMenu' onClick={()=>onClickTest(2, 'B2')}>
            Test2 (B2)
            </div>
            <div id='Test3FooterMenu' className='footerMenu' onClick={()=>onClickTest(3, 'B1')}>
            Test3 (B1)
            </div>
            <div id='Test4FooterMenu' className='footerMenu' onClick={()=>onClickTest(4, 'B1')}>
            Test4 (B1)
            </div>
            <div id='Test5FooterMenu' className='footerMenu' onClick={()=>onClickTest(5, 'B1')}>
            Test5 (B1)
            </div>
        </div>
    )

    let wordWork = (
        <div id='WordsFooterMenu'>
            <div id='WordsFooterMenuMain'>
            Words
            </div>
            <div id='SportFooterMenu' className='footerMenu'>
            Sport
            </div>                
            <div id='NatureFooterMenu' className='footerMenu'>
            Nature
            </div>                                
            <div id='SocietyFooterMenu' className='footerMenu'>
            Society
            </div>                  
            <div id='AppearanceFooterMenu' className='footerMenu'>
            Appearance
            </div>
            <div id='PrepositionsFooterMenu' className='footerMenu'>
            Prepositions
            </div>
            <div id='AccommodationFooterMenu' className='footerMenu'>
            Accommodation
            </div>
        </div>        
    )

    let listenWork = (
        <div id='ListenFooterMenu'>
            <div id='ListenFooterMenuMain'>
                Listen
            </div>
            <div id='Story1FooterMenu' className='footerMenu'>
                Story1
            </div>
            <div id='Story2FooterMenu' className='footerMenu'>
                Story2
            </div>
            <div id='Story3FooterMenu' className='footerMenu'>
                Story3
            </div>
            <div id='Story4FooterMenu' className='footerMenu'>
                Story4
            </div>
        </div>        
    )

    let phraseWork = (
        <div id='PhrasesFooterMenu'>
            <div id='PhrasesFooterMenuMain' className='footerMenu'>
            Phrases
            </div>                
            <div id='SpringFooterMain' className='footerMenu'>
            Spring
            </div>
            <div id='VacationFooterMenu' className='footerMenu'>
            Vacation
            </div>                
            <div id='GreatingsFooterMenu' className='footerMenu'>
            Greatings
            </div>
            <div id='PresentationFooter' className='footerMenu'>
            Presentation
            </div>                
            <div id='ThrasalVerbsFooter' className='footerMenu'>
            ThrasalVerbs
            </div>
        </div>        
    )

    let jokeWork = (
        <div id='JokesFooterMenu'>
            Jokes 
        </div>
    )

    let statisticWork = (
        <div id='StatisticsFooterMenu'>
            Statistics
        </div>
    )

    let dispatch  = useDispatch();

    imgShortMenuFile       = useSelector((store) => store.imgShortMenuFile); 

        work = (
            <>
                <div id='menuFooter1'>
                    {testWork}
                    {wordWork}
                    {listenWork}
                </div>

                <div id='menuFooter2'>
                    {phraseWork}
                    {jokeWork}
                    {statisticWork}
                </div>  

                <div id='menuFooter3'>
                    {testWork}
                    {wordWork}
                    {listenWork}
                    {phraseWork}
                    {jokeWork}
                    {statisticWork}
                </div>  
            </>            
        );

    return work;

} // end of FooterSmallBigScreen