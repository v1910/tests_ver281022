//MainReducer.js-----------------------------
   
// It is the store of the site

import React from "react";

import  "./MainReducer.css";

import group411_Head  from "./img/Group411_Head.svg";
import group412_Head  from "./img/Group412.svg";
import group414_Head  from "./img/Group414.svg";
import group70_Head   from "./img/Group70.svg";
import group413_Head  from "./img/Group413.svg";
import group240_Head  from "./img/Group240.svg";
import group241_Head  from "./img/Group241.svg";
import group416_Head  from "./img/Group416.svg";
import group422       from './img/Group422.svg';

import icon_a_blue      from "./img/icon_a.svg"; //answer symbol
import icon_b_blue      from "./img/icon_b.svg"; //answer symbol
import icon_c_blue      from "./img/icon_c.svg"; //answer symbol
import icon_d_blue      from "./img/icon_d.svg"; //answer symbol
import icon_e_blue      from "./img/icon_e.svg"; //answer symbol
import icon_f_blue      from "./img/icon_f.svg"; //answer symbol
import icon_g_blue      from "./img/icon_g.svg"; //answer symbol
import icon_a_white     from "./img/icon_a_white.svg"; //answer symbol
import icon_b_white     from "./img/icon_b_white.svg"; //answer symbol
import icon_c_white     from "./img/icon_c_white.svg"; //answer symbol
import icon_d_white     from "./img/icon_d_white.svg"; //answer symbol
import icon_e_white     from "./img/icon_e_white.svg"; //answer symbol
import icon_f_white     from "./img/icon_f_white.svg"; //answer symbol
import icon_g_white     from "./img/icon_g_white.svg"; //answer symbol
import icon_a_red       from "./img/icon_a_red.svg"; //answer symbol
import icon_b_red       from "./img/icon_b_red.svg"; //answer symbol
import icon_c_red       from "./img/icon_c_red.svg"; //answer symbol
import icon_d_red       from "./img/icon_d_red.svg"; //answer symbol
import icon_e_red       from "./img/icon_e_red.svg"; //answer symbol
import icon_f_red       from "./img/icon_f_red.svg"; //answer symbol
import icon_g_red       from "./img/icon_g_red.svg"; //answer symbol

import { AllTests } from '../components/allTests/AllTests.js';

import {CorrectAnswersTests} from '../components/correctAnswersTests/CorrectAnswersTests.js';

import {SOCIETYwords} from "../components/societyWords/society_words.js";
import {SPORTwords} from "../components/sportWords/sport_words.js";
import {ACCOMMODATIONwords} from "../components/accommodationWords/accommodation_words.js";
import {APPEARANCEwords} from "../components/appearanceWords/appearance_words.js";
import {PREPOSITIONSwords} from "../components/prepositionsWords/prepositions_words.js";
import {NATUREwords} from "../components/natureWords/nature_words.js";

import shortMenuOnOut        from "../components/menuMainPage/Group_466.svg"; //file for showing the short main menu


//import {Jokes} from "./components/jokes/Jokes.js";
//import { insertAfter } from "./components/insertAfter/InsertAfter.js";

let workAllTest = AllTests(); // read all tests
//let workTest = workAllTest[0].length; // amount of questions in current test

const axios = require('axios');

let initialStore = 

{
	//initialisation -----------
    state_edit: true,
    stateTests: false,
    stateWords: false,
    stateListen: false,
    statePhrases: false,
    stateJokes: false,
    itemMenu1: "",
    itemMenu2: "",
    all_input_sections: {
                            all_input_tests: 0,
                            all_input_words: 0,
                            all_input_listen: 0,
                            all_input_phrases: 0,
                            all_input_jokes: 0,
                            all_input_statistics: 0
                        }, // all inputs in every section
	 
//	 all_words: [], // array of all words
// 	 jokes_arr: [], // jokes array

//  	 nTests:  0, // quantity of tests
  	 

//	 idioms_files:  ["JOB","HOT","MIX"], // idioms files
  	
	/* initialize variables */
	 count:  0, 
	 clearTime:  0, 
	 seconds:  0,
	 minutes:  0,
	 hours:  0, 
	 clearState:  0, 
	 secs:  0,
	 mins:  0,
	 gethours:  0, 

     /* common variables ----*/
     colorBlue: '#3BB3BD', //blue
     colorLightRed: '#f0b4bc', //light red
     colorRed: '#ED2F4B', // red
     colorWhite: 'white', 

    // header ----------------
    tabletMaxScreenSize:    774, //880,  // max size of tablet screen
    visibContentShortMenu:  {display: 'none'}, // don't show the window of the short menu
    imgShortMenuFile:       true, //show Group305.svg, otherwise Group1011.svg (false)
    initSection2HomePage:   //init data of Section2 of Main Page
    <section id='section2MainPage'>
        <div id='overview'>
            Overview
        </div>
        <div id='contSection2MainPage'>
            <div id='contOverview'>
            <div className='contOverviewItem'>
                <div className='titleOverviewItem'>Tests</div>
                <div className="ellipseOrangeOverviewItem">
                    <img className='imgEllipseOverviewItem' src={group412_Head}/>
                </div>
                <div className="textEllipseOverviewItem">
                There are several tests with level B1 and B2. You can test your
                knowledge of English grammar and improve it by using the grammar rules
                for each question here.
                </div>
            </div>
            <div className='contOverviewItem'>
                <div className='titleOverviewItem'>Words</div>
                <div className="ellipseGreenOverviewItem">
                    <img className='imgEllipseOverviewItem' src={group414_Head}/>
                </div>
                <div className="textEllipseOverviewItem">
                Here you can increase your vocabulary on several popular topics 
                by trying to guess the correct word from the given examples.
                </div>
            </div>
            <div className='contOverviewItem'>
            <div className='titleOverviewItem'>Listen</div>
                <div className="ellipseBlueOverviewItem">
                    <img className='imgEllipseOverviewItem' src={group240_Head}/>
                </div>
                <div className="textEllipseOverviewItem">
                A good way to improve your understanding of English speech is 
                to listen to English novels. You can do  this here and control 
                yourself reading the text.
                </div>
            </div>
            <div className='contOverviewItem'>
            <div className='titleOverviewItem'>Phrases</div>
                <div className="ellipseBlueOverviewItem">
                    <img className='imgEllipseOverviewItem' src={group70_Head}/>
                </div>
                <div className="textEllipseOverviewItem">
                To be closer to a real Englishman, I recommend learning 
                phrasal verbs here on practical topics using useful sentences.
                </div>
            </div>
            <div className='contOverviewItem'>
            <div className='titleOverviewItem'>Jokes</div>
                <div className="ellipseOrangeOverviewItem">
                    <img className='imgEllipseOverviewItem' src={group241_Head}/>
                </div>
                <div className="textEllipseOverviewItem">
                Several jokes of the site allow you to definitely cheer yourself up.
                </div>
            </div>
            <div className='contOverviewItem'>
            <div className='titleOverviewItem'>Statistics</div>
                <div className="ellipseGreenOverviewItem">
                    <img className='imgEllipseOverviewItem' src={group413_Head}/>
                </div>
                <div className="textEllipseOverviewItem">
                Statistics are used to evaluate parts of the site in order to improve it.
                </div>
            </div>
            </div>
        </div>
    </section>,

    initSection3HomePage:    
    <section id='section3MainPage'>
        <div id='frequentlyQuestions'>
        Frequently asked questions
        </div>
        <div id='contImgQuestions'>
            <div id='contImgFrequentlyQuestions'>
            <img className='imgFrequentlyQuestions' src={group416_Head}/>
            </div>
            <div id='contQuestionsAnswers'>
            <div className='contQuestionAnswer'>
                <div className='contQuestion'>
                How are these tests different from other sites?
                </div>
                <div className='contAnswer'>
                You can read rules for each test question. 
                </div>
            </div>
            <div className='contQuestionAnswer'>
                <div className='contQuestion'>
                What methods do you use to improve the memorization of English words?              
                </div>
                <div className='contAnswer'>
                There are several centences which help the user to guess the word.
                </div>
            </div>
            <div className='contQuestionAnswer'>
                <div className='contQuestion'>
                Why do you think listening to English novels improves 
                understanding English speech?
                </div>
                <div className='contAnswer'>
                English novels should not only be listened to, but also read. 
                As a result, you should learn by ear earch word, 
                repeating this process as many times as necessery.
                </div>
            </div>
            <div className='contQuestionAnswer'>
                <div className='contQuestion'>
                What is the point of memorising and using phrasal verbs?
                </div>
                <div className='contAnswer'>
                Of couse, you can speak English without using phrasal verbs. 
                But using them brings you closer to a real Englishman.
                </div>
            </div>
            </div>
        </div>

    </section>,

    iconShortMenu:          shortMenuOnOut, // file name of short menu icon
    menuMainPage:           null,
    imgSection1Right:       (<div id='group411_Head'>
                                <img  id='imgGroup411Head' key='img1' src={group411_Head} />
                            </div>),    
    textSection1Left:       (<div className='contTitleText_880'>           
                                <div id='titleText'>
                                    Test your English level online
                                </div>  
                                <div id='titleTextDetail'>
                                    Here you can test and improve your knowledge 
                                    of English grammar, increase your vocabulary, enrich your speech
                                    with phraseological verbs, improve your understanding of English 
                                    speech by listening to novels and cheer up by reading jokes.
                                </div> 
                                <button id='buttonStartTest'>Start The Test</button> 
                            </div> ),                            
    currentBranchSite:      'Home',
//    screenSize:             window.innerWidth, //the size of the current screen
    
	// tests -----------------

    imgSection1RightTest: (
        <div id='contImgTest'>
            <img  id='imgGroup411Head' src={group422} />
        </div>
    ),

    textSection1LeftTest: '',

     showHideTest: null,

     list_tests_wrapper: 'hidden', // hide or show (visible) list_tests_wrapper

     state_reply: [], // state of reply

     state_button_close: [], // state of button close

     currentTest:  0, // the number of the current test

	 countDownDate:  new Date().getTime(), // start time for the chosing test

	 countDownDate_qst:  new Date().getTime(), // start time for the chosing question

  	 count_time_question:  null,  // all time for the current question

  	 count_time_test:  null, // all time for the current test

	 current_question:  0, // current question  ( 0  -  first)

     current_question_plus1:  1, // = current question + 1

     numberLevel:  null, // number of test Level

	 X_setInterval:  0, // id of clearInterval

	 tests:  workAllTest, // read all tests

	 nTests:  workAllTest.length, // amount of all tetsts

	 cAnswers: CorrectAnswersTests(),  // read all correct answers
	
	 selected_answer: -1,  // number of the selected answer in the current question

	 state_tests: [], // test state

     state_blue_red_user : [], //user choice of answer

     state_blue_red_corr : [], //correct answer

     state_count_time_test: [], //state of count time test

     state_count_time_question: [], // state of count time question

     correct_answer: -1,  // number of the correct answer in the current question  

     firstTimer: null,  // = null (start timer, other - stop)

     state_test: null, // state of every question: true -  current question. false

     WHY_botton_visibility: [], //{visibility: 'hidden'}, visibility of WHY button

     congrFinishTest: null,  // the phrase 'Congratulate you' after  finishing the test. At first it is null.

     setBlueVisibility: [],  //only active question can have yellow color with cover cursor

     section1MainPage: null, //section 1 of the main page

     section2MainPage: null, //section 2 of the main page

     width_id_sliderHeaderTest: 634,  // width of id=sliderHeaderTest is 634px in slider of  section 2

     headerSection2Test: null, // header of Section2 of Test

     showCurrentTest: null,  //  show Current Test

     activeTest: false, //=true: branch Tests was activated
     
     showButtonResults: false, //=true - show results button

     showRules: false,  //=true - show rules for every question

     showResults: false,  //=true - show results for every question

     workAnswerSymbolBlue:  [icon_a_blue,icon_b_blue,icon_c_blue,icon_d_blue,icon_e_blue,icon_f_blue,icon_g_blue],

     workAnswerSymbolWhite: [icon_a_white,icon_b_white,icon_c_white,icon_d_white,icon_e_white,icon_f_white,icon_g_white],

     workAnswerSymbolRed:   [icon_a_red,icon_b_red,icon_c_red,icon_d_red,icon_e_red,icon_f_red,icon_g_red],

     styleNext:  {display: 'none'}, // button Next is shown, else - hide

     currQuestProps: [], //current Question Properties


     // words -----------------
     all_words: [SOCIETYwords(),SPORTwords(),ACCOMMODATIONwords(),APPEARANCEwords(),
                 PREPOSITIONSwords(),NATUREwords()], // array of all words

     showHideWords:                             null,  //hide words in Words.js

     words_wrapper:                             null,

     count_pick_button_show_answer:             0,

	 work_arr:                                  [], // array of random numbers

	 count_pick_button_show_word:               0,  //count of picking button_show_word

	 count_pick_button_show_description:        0, //count of picking button_show_description

	 current_number_word:                       0,  //current number word

	 current_number_word_group:                 0, // current word group (SOCIETY)

	 count_pick_button_show_answer:             0,

	 nWords:                                    0, // quantity of words

     words_files:  ["SOCIETY","SPORT","ACCOMMODATION", "APPEARANCE", "PREPOSITIONS", "NATURE"], // words files

	 words:                                     [], // words array

     state_button_next_descr_color:             'white',

     list_words_wrapper:                        'hidden', //hide (show) words list

     state_label_yes_no_word_style:             {color:  'green', visibility: 'hidden'},

     input_input_word_value:                    '',

     button_show_descr_style:                   "color: white",

     button_show_words_style:                   "color: white",

     state_label_next_descr_value:               '',

     state_input_word_value:                     '',  

     state_label_yes_no_word_value:              '',

     state_tate_label_answer_value:              '',

     state_label_answer_visibility:              'hide',

     state_button_show_words_color:              'white',

     state_label_show_words_value:               '',

     state_label_show_words_visibility:          'hide',

     state_label_show_transcription_visibility:  'hide',

     state_label_show_transcription_value:       '',

     state_button_next_word_value:               'Next Word ' + ' 1' +'/'+ '0',

     state_label_answer_value:                   '', // value of answer

     checkStyle:                                 {backgroundColor: 'rgba(154,136,112,0.5)'},

     up:                                         false, //false: button UP is not active, true: other

     showHideWordsInstruction:                   false, // false: button hides instructions, true: other
     

	// listen --------------

     showHideListen:                            null,

	 nAudio:                                    4,  // amount of all audio files

     currentAudio:                              1, //current audio file

     list_listen_wrapper:                       'hidden',  // hide list of audio list

     showHideListenText:                        false, //hide text of current audio-file

     content_audio:                             null, //text audio content

     audioTitleName:                            ['Mr. Knowall', 'The Thee Fat Women of Antibes', 'The Point of Honour', 'The Escape'], // audio title name

     
    // phrases -----------------

    showHidePhrases:                            null,  //do not show Phrases

    currentPhrases:                             "Greatings", //current Phrases file   "/home",

    list_phrases_wrapper:                       'hidden',

    phrases_collections:                        ["Greatings","PhrasalVerbs","Presentation", "Spring", "Vacation"], // phrases collections of DB

    phrases:                                    null,

    phrases_wrapper_visibility:                 {display: 'none'},


	// jokes -----------------

     showHideJokes:                             null,

     currentJokes:                              "Jokes",

     jokes:                                     null,
	

    // statistics ------------

    showHideStatistics:                         null,

    currentStatistics:                          "Statistics", // statistics collection

    thanksStatistics:                           null,//Thank you!  after sending form

    statistics_wrapper_visibility:              {visibility: 'visible'},

    statistics_form_visibility:                 {display: 'block'}, // form visibility


    all_input_statisticsDB:                     null,

    all_input_statistics:                       null,

    //Footer --------------

    mailFormStyle:                              {display: 'none'}, // mailForm visibility

    inputEmailValue:                            null,

    errorEmailText:                             null, //visibility sending the letter

    styleSendOK:                                {display: 'none'},  

    opacityOK:                                  1

}; //initialStore  

let workInitialStore = initialStore;

initialStore.count_questions_test = workAllTest[workInitialStore.currentTest].length; // amount of questions in current test

//initialStore.nJokes = workInitialStore.jokes_arr.length // amount of all jokes

initialStore.count_correct_answer = Array(initialStore.count_questions_test).fill(null);  // count of correct answers for every question
    
initialStore.count_time_question = Array(initialStore.count_questions_test).fill('00:00');  // all time for the current question
 
//initialStore.count_time_test = Array(initialStore.count_questions_test).fill('00:00'); // all time for the current test
initialStore.count_time_test = '00:00'; // all time for the current test

initialStore.state_test = Array(initialStore.count_questions_test).fill(true); // state of every question: true -  current question. false

initialStore.state_test[0] = false; 

initialStore.state_blue_red_user  = Array(initialStore.count_questions_test).fill(-1);// user answer 

initialStore.state_blue_red_corr  = Array(initialStore.count_questions_test).fill(-1);// correct answer 
                                                            
initialStore.state_button_close = Array(initialStore.count_questions_test).fill(0);// state of close button                                                             

initialStore.state_reply = Array(initialStore.count_questions_test).fill(' ');// state of close button  

initialStore.WHY_botton_visibility = Array(initialStore.count_questions_test).fill({display: 'none'});// visibility of WHY

initialStore.setBlueVisibility = Array(initialStore.count_questions_test).fill('no_li_class no_pointer');// it is the class with yellow color (cover pointer)


////console.log('MainReducer:--- init:  initialStore.state_reply=',initialStore.state_reply);  

function MainReducer(state = initialStore, action){
//    console.log('MainReducer:--- action=',action);

//console.log('MainReducer: state.state_blue_red_user[0]=',state.state_blue_red_user[0]);
//console.log('MainReducer: initialStore.width_id_sliderHeaderTest =',initialStore.width_id_sliderHeaderTest );

    let payload = action.payload;

    switch(action.type) {
//================================================================================        
        // HOME----------------------
        case 'InitSection1HomePage':       
//console.log('InitSection1HomePage: textSection1Left=',payload.textSection1Left);        
            return {
                ...state,
                imgSection1Right: payload.imgSection1Right,
                textSection1Left: payload.textSection1Left                       
        }         

        case 'InitSection2HomePage':       
            return {
                ...state,
                initSection2HomePage: payload.initSection2HomePage
        }      
        
        case 'InitSection3HomePage':       
            return {
                ...state,
                initSection3HomePage: payload.initSection3HomePage
        }      

//================================================================================        
        // HEADER----------------------
        case 'contShortMenu':       
//console.log(' MainReducer: contShortMenu: payload.visibContentShortMenu=',payload.visibContentShortMenu);                
//console.log(' MainReducer: contShortMenu: payload.imgShortMenuFile=',payload.imgShortMenuFile);
            return {
                ...state,
                visibContentShortMenu:    payload.visibContentShortMenu,
                imgShortMenuFile:         payload.imgShortMenuFile,
                iconShortMenu:            payload.iconShortMenu
        } 
//============================================================================
        case 'MenuMainPage_onClickTest':       
console.log(' MainReducer: header_testDispatch: payload.currentTest=',payload.currentTest, '  payload.numberLevel',payload.numberLevel);        
            {
//                let count_questions_test        = state.tests[state.payload.currentTest - 1].length; // amount of questions in current test
                clearInterval(state.X_setInterval);
                //for section1 (tests)
                state.current_question_plus1 = 1;
                state.textSection1LeftTest = (
                    <div className='contTitleTextTest'>           
                        <div id='titleTextSection1Tests'>
                            Home > TEST {payload.currentTest}, level {payload.numberLevel} > <span id='titleTextSection1TestsQuestion'>Question {state.current_question_plus1}</span> 
                        </div> 
                        <div>
                            Welcome to the English level tests!
                        </div>  
                    </div> 
                );
            }
        return {
            ...state,
            currentTest:          payload.currentTest - 1,
            currentBranchSite:    'Tests', //='Home' for Home branch, ='Tests'for test, ='Words','Listen', 'Phrases','Jokes','Statistics'
            initSection3HomePage: null,
            numberLevel:          payload.numberLevel,
            current_question:     0,
            current_question_plus1: 1,
            countDownDate_qst:    new Date().getTime(), // start time for the choosing test,
            activeTest:           true,
            count_correct_answer: Array(state.count_questions_test).fill(null),  // count of correct answers for every question
            showResults:          false, //true - show results for this question
            showRules:            false, //true - show rules for this question
            showButtonRules:      false,
            styleNext:            {display: 'none'},
            textSection1Left:     state.textSection1LeftTest,
            imgSection1Right:     state.imgSection1RightTest,
            state_blue_red_user:  Array(state.count_questions_test).fill(-1),// user answer ,
            state_blue_red_corr:  Array(state.count_questions_test).fill(-1),// correct answer 
            count_time_test:      '00:00', // all time for the current test
            count_time_question:  Array(state.count_questions_test).fill('00:00'),  // all time for the current question
            countDownDate:        new Date().getTime(), // start time for the chosing test
            firstTimer:           null,
            count_questions_test: state.count_questions_test

        } 
//let currentTest = numberTest-1;
//let current_question = 0;
//let current_question_plus1 = 1;
//let count_correct_answer = Array(count_questions_test).fill(null);  // count of correct answers for every question

//clearInterval(X_setInterval);
/*
dispatch({ type: 'MenuMainPage_onClickTest', payload: 
    {   
        currentTest:            currentTest,
        currentBranchSite:      'Tests',
        initSection3HomePage:   null,
        numberLevel:            numberLevel,
        current_question:       current_question,
        current_question_plus1: current_question_plus1,
        countDownDate_qst:      new Date().getTime(), // start time for the choosing test
        activeTest:             true
    }
});

dispatch({type: 'FooterQuestionTest_showResults',  
    payload: {
        showResults:  false, //true - show results for this question
    }
}); 

dispatch({type: 'FooterQuestionTest_showButtonRules',  
    payload: {
        showButtonRules:    false
    }
});

dispatch({type: 'MenuMainPage_styleNext',  
    payload: {
        styleNext:                {display: 'none'}
    }
});

//console.log('onClickTest: current_question=',current_question);     

//for section1 (tests)
textSection1LeftTest = (
    <div className='contTitleTextTest'>           
        <div id='titleTextSection1Tests'>
            Home > TEST {numberTest}, level {numberLevel} > <span id='titleTextSection1TestsQuestion'>Question {current_question_plus1}</span> 
        </div> 
        <div>
            Welcome to the English level tests!
        </div>  
    </div> );

dispatch({type: 'InitSection1HomePage', 
    payload: {
        imgSection1Right: imgSection1RightTest,
        textSection1Left: textSection1LeftTest
    }
});   

count_questions_test        = tests[currentTest].length; // amount of questions in current test

//        state_blue_red_user         = Array(count_questions_test).fill(-1);// user answer 

state_blue_red_corr         = Array(count_questions_test).fill(-1);// correct answer 

state_count_time_test       = Array(count_questions_test).fill(0);// state of close button                                                             

//        state_count_time_question   = []; // state of count time question



//        count_time_test             = Array(count_questions_test).fill('00:00'); // all time for the current test


dispatch({type: 'MenuMainPage_Init', 
    payload: {
        state_blue_red_user:  Array(count_questions_test).fill(-1),// user answer ,
        state_blue_red_corr:  Array(count_questions_test).fill(-1),// correct answer 
        count_time_test:      '00:00', // all time for the current test
        count_time_question:  Array(count_questions_test).fill('00:00'),  // all time for the current question
        countDownDate:        new Date().getTime(), // start time for the chosing test
        firstTimer:           null,
        count_questions_test: count_questions_test,
        count_correct_answer: count_correct_answer
    }
});
*/
//===============================


        case 'header_testDispatch':       
            return {
                ...state,
                currentTest:           payload.currentTest,
                currentBranchSite:     payload.currentBranchSite,
                initSection3HomePage:  payload.initSection3HomePage,
                numberLevel:           payload.numberLevel              
        } 

        case 'headSections':       
            return {
                ...state,
                section1MainPage: payload.section1MainPage,
                section2MainPage: payload.section2MainPage                            
        } 

        case 'MenuMainPage_menuMainPage':       
//console.log(' MenuMainPage_menuMainPage: payload.menuMainPage=',payload.menuMainPage);        
        return {
            ...state,            
            menuMainPage:   payload.menuMainPage
        }              

//        case 'ScreenSize':     //the size of the current screen  
//console.log('ScreenSize: screenSize=',payload.screenSize);           
//        return {
//            ...state,            
//            screenSize:          payload.screenSize
//        }              

        // TESTS----------------------
        case 'HeaderTests_mouseEnterList':       
//console.log('1 MainReducer: HeaderTests_mouseEnterList: payload.list_tests_wrapper=',payload.list_tests_wrapper);                
            return {
                ...state,
                count_time_question:    payload.count_time_question, 
                count_time_test:        payload.count_time_test,
                list_tests_wrapper:     payload.list_tests_wrapper, 
                selected_answer:        payload.selected_answer, 
                correct_answer:         payload.correct_answer, 
                current_question:       payload.current_question,
                count_correct_answer:   payload.count_correct_answer
            }
            

        case 'HeaderTests_mouseLeaveList':       
            return {
                ...state,
                list_tests_wrapper: payload.list_tests_wrapper
            }

        case 'ShowCurrentTest_currentTest':       
            return {
                ...state,
//                currentTest:        payload.list_tests_wrapper,
                section1MainPage:   payload.section1MainPage,
                section2MainPage:   payload.section2MainPage
        }

        case 'HeaderTestsList':       
//console.log('1 MainReducer: HeaderTestsList: payload.all_input_sections=',payload.all_input_sections);    
            axios.post('/postAllInsertSections', {
                sections: payload.all_input_sections
            })                                     
//console.log('2 MainReducer: HeaderTestsList: payload.all_input_sections=',payload.all_input_sections);                
            return {
                ...state,
                currentTest:        payload.currentTest, 
                showHideTest:       payload.showHideTest,
                list_tests_wrapper: payload.list_tests_wrapper,
                countDownDate:      payload.countDownDate, // start time for the chose test
                countDownDate_qst:  payload.countDownDate_qst, // start time for the chose question
                state_test:         payload.state_test,
                state_blue_red :    payload.state_blue_red ,
                firstTimer:         null,
                showHideTests:      payload.showHideTests,
                showHideWords:      payload.showHideWords,
                showHideListen:     payload.showHideListen,
                showHidePrases:     payload.showHidePrases,
                showHideJokes:      payload.showHideJokes,
                showHideStatistics: payload.showHideStatistics,
                prases:             payload.prases,
                phrases_wrapper_visibility: payload.phrases_wrapper_visibility,
                WHY_botton_visibility: payload.WHY_botton_visibility,
                congrFinishTest:    payload.congrFinishTest,
                up:                 payload.up,
                all_input_sections: payload.all_input_sections
            }

        case 'ShowCurrentTest_handleChange':       
            return {
                ...state,
                state_blue_red_user:  payload.state_blue_red_user, 
                state_blue_red_corr:  payload.state_blue_red_corr,
                state_tests:          payload.state_test,
                current_question:     payload.current_question,
                selected_answer:      payload.selected_answer,
                count_correct_answer: payload.count_correct_answer
            }
            
        case 'HeaderSection2Test_count_time_test':  
//console.log('MainReducer: ShowCurrentTest_startWatch4: payload.count_time_test=', payload.count_time_test, ' payload.X_setInterval=',payload.X_setInterval);
            return {
                ...state,            
                count_time_test:    payload.count_time_test,
                X_setInterval:      payload.X_setInterval,
                activeTest:         payload.activeTest,
                countDownDate_qst:  payload.countDownDate_qst // start time for the chose question                
            }

        case 'HeaderSection2Test_X_setInterval':   
            return {
                ...state,                     
                X_setInterval:          payload.X_setInterval
            }            

            case 'ShowCurrentTest':   
            return {
                ...state,                     
                WHY_botton_visibility: payload.WHY_botton_visibility
            }            


        case 'footerQuestion_why':       
            return {
                ...state,            
                state_reply:        payload.state_reply,
                state_button_close: payload.state_button_close
            }

        case 'footerQuestion_answer_close':       
            return {
                ...state,            
                state_reply:        payload.state_reply,
                state_button_close: payload.state_button_close,
                showHideTest:       payload.showHideTest
            }

        case 'QuestionTest':       
            return {
                ...state,            
                WHY_botton_visibility:   payload.WHY_botton_visibility 
            }

        case 'Test_UP':            
            return {
                ...state,            
                up:   payload.up 
            }
         
        case 'headerSection2Test':       
            return {
                ...state,            
                headerSection2Test:   payload.headerSection2Test 
            }            

        case 'mainSection2Test':       
            return {
                ...state,            
                mainSection2Test:   payload.mainSection2Test
            }                        

        case 'AnswerTest_state_blue_red':       
            return {
                ...state,            
                state_blue_red_user:   payload.state_blue_red_user,
                state_blue_red_corr:   payload.state_blue_red_corr,
                count_correct_answer:  payload.count_correct_answer,
                styleNext:             payload.styleNext,
                selected_answer:       payload.selected_answer
            }

        case 'FooterQuestionTest_current_question':       
//console.log('FooterQuestionTest_current_question: current_question=',payload.current_question);          
            return {
                ...state,            
                current_question:         payload.current_question,
                current_question_plus1:   payload.current_question_plus1,
                styleNext:                payload.styleNext
            }            

        case 'FooterQuestionTest_showButtonResults':       
            return {
                ...state,            
                showButtonResults:  payload.showButtonResults
                
            }    
            
        case 'FooterQuestionTest_showResults':       
            return {
                ...state,            
                showResults:        payload.showResults  //= true: show results, other - false
            }

        case 'FooterQuestionTest_showButtonRules':       
            return {
                ...state,            
                showButtonRules:  payload.showButtonRules
            }             

        case 'FooterQuestionTest_showRules':       
            return {
                ...state,            
                showRules:         payload.showRules,
                currentRules:      payload.currentRules
            }                

        case 'MenuMainPage_Init':       
            return {
                ...state,            
                state_blue_red_user:   payload.state_blue_red_user,
                state_blue_red_corr:   payload.state_blue_red_corr,
                count_time_test:       payload.count_time_test,
                count_time_question:   payload.count_time_question,
                countDownDate:         payload.countDownDate,
                firstTimer:            payload.firstTimer,
                count_questions_test:  payload.count_questions_test,
                count_correct_answer:  payload.count_correct_answer
            }            

        case 'FooterQuestionTest_imgSection1RightTest':       
            return {
                ...state,            
                imgSection1RightTest:         payload.imgSection1RightTest
            }                            

        case 'MenuMainPage_currQuestProps':       
            return {
                ...state,            
                currQuestProps:         payload.currQuestProps
            }      
            
        case 'FooterQuestionTest_currQuestProps':       
            return {
                ...state,            
                currQuestProps:         payload.currQuestProps
            }                  

            case 'MenuMainPage_styleNext':       
            return {
                ...state,            
                styleNext:         payload.styleNext
            }                  


//================================================================================   
        //WORDS--------------------------

        case 'HeaderWords_mouseEnterList_mouseLeaveList': 
                
            return {
                ...state,
                words_wrapper:      payload.words_wrapper,
                list_words_wrapper: payload.list_words_wrapper
            };       
            
        case 'HeaderWordsList_noVisibilityWords':                
            return {
                ...state,
                list_words_wrapper:  payload.list_words_wrapper
            };                     

        case 'HeaderWordsList':                
            axios.post('/postAllInsertSections', {
                sections: payload.all_input_sections
            })       
//console.log('MainReducer: HeaderWordsList: ShowHideStatistics=',payload.ShowHideStatistics)        
            return {
                ...state,
                list_words_wrapper:                         payload.list_words_wrapper,
                count_pick_button_show_word:                payload.count_pick_button_show_word,
                count_pick_button_show_description:         payload.count_pick_button_show_description,
                current_number_word:                        payload.current_number_word,
                count_pick_button_show_answer:              payload.count_pick_button_show_answer,
                current_number_word_group:                  payload.current_number_word_group,
                state_button_next_descr_color:              payload.state_button_next_descr_color,
                state_label_next_descr_value:               payload.state_label_next_descr_value,
                state_input_word_value:                     payload.state_input_word_value,
                state_label_yes_no_word_value:              payload.state_label_yes_no_word_value,
                state_label_yes_no_word_style:              payload.state_label_yes_no_word_style,
                state_tate_label_answer_value:              payload.state_tate_label_answer_value,
                state_label_answer_visibility:              payload.state_label_answer_visibility,
                state_button_show_words_color:              payload.state_button_show_words_color,
                state_label_show_words_value:               payload.state_label_show_words_value,
                state_label_show_words_visibility:          payload.state_label_show_words_visibility,
                state_label_show_transcription_value:       payload.state_label_show_transcription_value,
                state_button_next_word_value:               payload.state_button_next_word_value,
                work_arr:                                   payload.work_arr,
                input_input_word_value:                     payload.input_input_word_value,
                showHideTest:                               payload.showHideTest,
                showHideWords:                              payload.showHideWords,                
                showHideListen:                             payload.showHideListen,                                                                                  
                showHidePhrases:                            payload.showHidePhrases,
                showHideJokes:                              payload.showHideJokes,
                ShowHideStatistics:                         payload.ShowHideStatistics,
                statistics_wrapper_visibility:              payload.statistics_wrapper_visibility,
                phrases_wrapper_visibility:                 payload.phrases_wrapper_visibility,
                checkStyle:                                 payload.checkStyle,
                all_input_sections:                         payload.all_input_sections
            };         

        case 'ShowWordTest_showDescr':  
//console.log('MainReducer: ShowWordsTest_showDescr: payload.count_pick_button_show_description=',payload.count_pick_button_show_description)                      
//console.log('MainReducer: ShowWordsTest_showDescr: payload.state_button_next_descr_color=',payload.state_button_next_descr_color)
//console.log('MainReducer: ShowWordsTest_showDescr: payload.state_label_next_descr_value=',payload.state_label_next_descr_value)
            return {
                ...state,
                state_button_next_descr_color:      payload.state_button_next_descr_color,
                state_label_next_descr_value:       payload.state_label_next_descr_value,
                count_pick_button_show_description: payload.count_pick_button_show_description,           
                work_arr:                           payload.work_arr,
                nWords:                             payload.nWords
            };                                              

        case 'ShowWordsTest_input_input_word':                
            return {
                ...state,
                input_input_word_value:         payload.input_input_word_value,
                work_arr:                       payload.work_arr,
                state_label_next_descr_value:   payload.state_label_next_descr_value,
                state_button_next_word_value:   payload.state_button_next_word_value,
                nWords:                         payload.nWords,
                checkStyle:                     payload.checkStyle
            };                                                                  

            
        case 'ShowWordsTest_button_input_word':                
//console.log('MainReducer: state_label_yes_no_word_value=',payload.state_label_yes_no_word_value)         
            return {
                ...state,
                state_label_yes_no_word_value:  payload.state_label_yes_no_word_value,
                state_label_yes_no_word_style:  payload.state_label_yes_no_word_style,
                work_arr:                       payload.work_arr,
                state_label_next_descr_value:   payload.state_label_next_descr_value,
                nWords:                         payload.nWords
            };    

        case 'ShowWordsTest_showAnswer':                
//console.log('MainReducer: state_button_next_word_value=',payload.state_button_next_word_value)         
            return {
                ...state,
                state_label_answer_value:       payload.state_label_answer_value,
                state_label_answer_visibility:  payload.state_label_answer_visibility,
                work_arr:                       payload.work_arr,
                state_label_next_descr_value:   payload.state_label_next_descr_value,
                nWords:                         payload.nWords,
                state_button_next_word_value:   payload.state_button_next_word_value
            };                                                                           
          

        case 'ShowWordsTest_showWord2':                
//console.log('MainReducer: ShowWordsTest_showWord2: state_label_show_words_value=',payload.state_label_show_words_value)        
            return {
                ...state,
                state_label_show_words_value:       payload.state_label_show_words_value,
                state_button_show_words_color:      payload.state_button_show_words_color,
                state_label_show_words_visibility:  payload.state_label_show_words_visibility,
                count_pick_button_show_word:        payload.count_pick_button_show_word,
                state_button_next_word_value:       payload.state_button_next_word_value,        
                work_arr:                           payload.work_arr,
                state_label_next_descr_value:       payload.state_label_next_descr_value,
                nWords:                             payload.nWords
            };    

        case 'ShowWordsTest_showTranscription':                
//console.log('MainReducer: ShowWordsTest_showTranscription: state_label_next_descr_value=',payload.state_label_next_descr_value);        
            return {
                ...state,
                state_label_show_transcription_value:       payload.state_label_show_transcription_value,
                state_label_show_transcription_visibility:  payload.state_label_show_transcription_visibility,
                nWords:                                     payload.nWords,
                state_label_next_descr_value:               payload.state_label_next_descr_value,
                work_arr:                                   payload.work_arr            
            };               

        case 'ShowWordsTest_button_next_word':                
//console.log('MainReducer: ShowWordsTest_button_next_word: state_button_next_word_value=',payload.state_button_next_word_value)                
            return {
                ...state,
                state_button_next_descr_color:                  payload.state_button_next_descr_color,
                state_label_next_descr_value:                   payload.state_label_next_descr_value,
                state_input_word_value:                         payload.state_input_word_value,       
                state_label_yes_no_word_value:                  payload.state_label_yes_no_word_value,
                state_label_answer_value:                       payload.state_label_answer_value,
                state_label_answer_visibility:                  payload.state_label_answer_visibility,
                state_button_show_words_color:                  payload.state_button_show_words_color,
                state_label_show_words_value:                   payload.state_label_show_words_value,
                state_label_show_words_visibility:              payload.state_label_show_words_visibility,    
                state_label_show_transcription_value:           payload.state_label_show_transcription_value,
                state_button_next_word_value:                   payload.state_button_next_word_value,
                input_input_word_value:                         payload.input_input_word_value,
                button_show_descr_style:                        payload.button_show_descr_style,
                button_show_words_style:                        payload.button_show_words_style,
                current_number_word:                            payload.current_number_word,
                work_arr:                                       payload.work_arr,
                nWords:                                         payload.nWords
                        
            };     


        case 'ShowWordTest_instructions':                
            return {
                ...state,
                showHideWordsInstruction:       payload.showHideWordsInstruction,    
            };                  

//================================================================================
        //LISTEN--------------------------

        case 'HeaderListen_mouseEnterList':                
//console.log('MainReducer: HeaderListen_mouseEnterList: payload.all_input_sections=',payload.all_input_sections);        
            return {
                ...state,
                list_listen_wrapper: payload.list_listen_wrapper
            };               

        case 'HeaderListen_mouseLeaveList':                
//console.log('MainReducer: HeaderListen_mouseLeaveList: state_label_next_descr_value=',payload.list_listen_wrapper);        
            return {
                ...state,
                list_listen_wrapper: payload.list_listen_wrapper
            };                           

        case 'HeaderListenList':                
            axios.post('/postAllInsertSections', {
                sections: payload.all_input_sections
            })     
//console.log('MainReducer: HeaderListenList: state_label_next_descr_value=',payload.showHideListen);        
            return {
                ...state,
                currentAudio:           payload.currentAudio, 
                showHideTest:           payload.showHideTest,
                showHideWords:          payload.showHideWords,  
                showHideListen:         payload.showHideListen, 
                showHidePhrases:        payload.showHidePhrases,
                showHideJokes:          payload.showHideJokes,
                ShowHideStatistics:     payload.ShowHideStatistics,
                showHideListenText:     payload.showHideListenText,
                phrases:                payload.phrases,
                list_tests_wrapper:     payload.list_tests_wrapper,
                list_words_wrapper:     payload.list_words_wrapper,
                statistics_wrapper_visibility: payload.statistics_wrapper_visibility,
                phrases_wrapper_visibility:    payload.phrases_wrapper_visibility,
                all_input_sections:     payload.all_input_sections
            };               

        case 'ShowCurrentListen':                
//console.log('MainReducer: ShowCurrentListen: showHideListenText=',payload.showHideListenText);        
            return {
                ...state,
                showHideListenText: payload.showHideListenText
            };                                       

        case 'ShowCurrentListenTextFile':                
//console.log('MainReducer: ShowCurrentListenTextFile: content_audio=',payload.content_audio);        
            return {
                ...state,
                content_audio: payload.content_audio
            };                                               

//================================================================================    
        //PHRASES--------------------------

        case 'HeaderPhrases_mouseEnterList':                
//console.log('MainReducer: HeaderPhrases_mouseEnterList: list_phrases_wrapper: =',payload.list_phrases_wrapper);        
            return {
                ...state,
                list_phrases_wrapper: payload.list_phrases_wrapper
            };               

        case 'HeaderPhrases_mouseLeaveList':                
//console.log('MainReducer: HeaderPhrases_mouseLeaveList: list_phrases_wrapper=',payload.list_phrases_wrapper);        
            return {
                ...state,
                list_phrases_wrapper: payload.list_phrases_wrapper
            };                           

        case 'HeaderPhrasesList':  
            axios.post('/postAllInsertSections', {
                sections: payload.all_input_sections
            }) 

            axios.get('/get'+payload.currentPhrases).then(resp => {

                payload.phrases = resp.data;
    //            console.log('MainReducer: HeaderPhrasesList: payload.phrases=',payload.phrases);                 
            });

//console.log('MainReducer: HeaderPhrasesList: showHideListen=',payload.showHideListen);        
//console.log('MainReducer: HeaderPhrasesList: currentPhrases=',payload.currentPhrases); 

            return {
                ...state,
                currentPhrases:             payload.currentPhrases, 
                showHideTest:               payload.showHideTest,
                showHideWords:              payload.showHideWords,  
                showHideListen:             payload.showHideListen,                                                                                  
                showHidePhrases:            payload.showHidePhrases,   
                showHideJokes:              payload.showHideJokes, 
                ShowHideStatistics:         payload.ShowHideStatistics,  
                phrases_wrapper_visibility: payload.phrases_wrapper_visibility,                                                                            
                list_tests_wrapper:         payload.list_tests_wrapper,
                list_words_wrapper:         payload.list_words_wrapper,
                list_listen_wrapper:        payload.list_listen_wrapper,
                phrasesTitle:               payload.phrasesTitle,
                statistics_wrapper_visibility: payload.statistics_wrapper_visibility,
                all_input_sections:         payload.all_input_sections
            };               

        case 'ShowCurrentPhrases':                
//console.log('MainReducer: ShowCurrentPhrases: phrases=',payload.phrases);        
            return {
                ...state,
                phrases: payload.phrases
            };                           

//================================================================================  
        //JOKES--------------------------

        case 'ShowCurrentJokes':                
//console.log('MainReducer: ShowCurrentJokes: jokes=',payload.jokes);        
            return {
                ...state,
                jokes: payload.jokes
            };                                   

        case 'HeaderJokes_mouseEnterList':                
//console.log('MainReducer: HeaderJokes_mouseEnterList: jokes=',payload.list_jokes_wrapper);        
            return {
                ...state,
                list_jokes_wrapper: payload.list_jokes_wrapper
            };                                              

        case 'HeaderJokes_mouseLeaveList':                
//console.log('MainReducer: HeaderJokes_mouseLeaveList: jokes=',payload.list_jokes_wrapper);        
            return {
                ...state,
                list_jokes_wrapper: payload.list_jokes_wrapper
            }; 
            
        case 'HeaderJokes':
            axios.post('/postAllInsertSections', {
                sections: payload.all_input_sections
            })                            
//console.log('MainReducer: HeaderJokes: showHideJokes=',payload.showHideJokes);        
            return {
                ...state,
                showHideTest:           payload.showHideTest,
                showHideWords:          payload.showHideWords,  
                showHideListen:         payload.showHideListen,                                                                                  
                showHidePhrases:        payload.showHidePhrases,    
                showHideJokes:          payload.showHideJokes,
                ShowHideStatistics:     payload.ShowHideStatistics,
                list_tests_wrapper:     payload.list_tests_wrapper,
                list_words_wrapper:     payload.list_words_wrapper,
                list_listen_wrapper:    payload.list_listen_wrapper,
                phrases:                payload.phrases,
                statistics_wrapper_visibility: payload.statistics_wrapper_visibility,
                phrases_wrapper_visibility:    payload.phrases_wrapper_visibility,
                all_input_sections:     payload.all_input_sections
            }; 

//================================================================================ 
        //STATISTICS--------------------------

        case 'HeaderStatistics':                
//console.log('MainReducer: HeaderStatistics: showHideStatistics=',payload.showHideStatistics);             
            axios.post('/postAllInsertSections', {
                sections: payload.all_input_sections
            })       
            return {
                ...state,
                showHideTest:           payload.showHideTest,
                showHideWords:          payload.showHideWords,  
                showHideListen:         payload.showHideListen,                                                                                  
                showHidePhrases:        payload.showHidePhrases,    
                showHideJokes:          payload.showHideJokes,
                showHideStatistics:     payload.showHideStatistics,
                list_tests_wrapper:     payload.list_tests_wrapper,
                list_words_wrapper:     payload.list_words_wrapper,
                list_listen_wrapper:    payload.list_listen_wrapper,
                phrases:                payload.phrases,
                statistics_wrapper_visibility: payload.statistics_wrapper_visibility,
                all_input_sections:     payload.all_input_sections,
                phrases_wrapper_visibility: payload.phrases_wrapper_visibility
            }; 
            
        case 'Statistics_statistics':                
//console.log('MainReducer: Statistics: statistics=',payload.statistics);        
            return {
                        ...state,
                        statistics:             payload.statistics
                    }; 

        case 'ShowCurrentStatisyics_thankYou':                
//console.log('MainReducer: ShowCurrentStatisyics_thankYou: thanksStatistics=',payload.thanksStatistics);        
//console.log('MainReducer: ShowCurrentStatistics_thankYou: statistics_form_visibility=',payload.statistics_form_visibility);        
            return {
                        ...state,
                        thanksStatistics:           payload.thanksStatistics,
                        statistics_form_visibility: payload.statistics_form_visibility
                    };                     

        case 'Statistics_thanksStatistics':                
//console.log('MainReducer: Statistics_thanksStatistics: thanksStatistics=',payload.thanksStatistics);        
            return {
                        ...state,
                        thanksStatistics:           payload.thanksStatistics
                    };                     

        case 'Statistics_AllInsertSectionsDB':                
//console.log('MainReducer: Statistics_AllInsertSections: all_input_sectionsDB=',payload.all_input_sectionsDB);        
            return {
                        ...state,
                        all_input_sections:           payload.all_input_sections
                    };                     
          

//================================================================================ 
        //FOOTER
        case 'Footer':                
            return {
                        ...state,
                        mailFormStyle:           payload.mailFormStyle
                    };                     
        
        case 'FooterEmail':                
//console.log('FooterEmail: contactEmail=',payload.contactEmail);              
//console.log('FooterEmail: contactComment=',payload.contactComment); 
            axios.post('/FooterEmail', {
                contactEmail:           payload.contactEmail,
                contactComment:         payload.contactComment                
            })                  

            return {
                        ...state,
                        contactEmail:           payload.contactEmail,
                        contactComment:         payload.contactComment,
                        mailFormStyle:          payload.mailFormStyle,
                        styleSendOK:            payload.styleSendOK
//                        opacityOK:              payload.opacityOK
                    };                     

        case 'footerOpacityOK':                
//console.log('footerOpacityOK: payload.styleSendOK=',payload.styleSendOK);        
            return {
                        ...state,
                        styleSendOK:           payload.styleSendOK
                    };                

        case 'footerInputEmail':     
//console.log('MainReducer: payload.errorEmailText=',payload.errorEmailText)
            if(payload.errorEmailText !== null) document.getElementById('inputEmail').focus();
            return {
                        ...state,
                        inputEmailValue:           payload.inputEmailValue,
                        errorEmailText:            payload.errorEmailText
                    };                

        default:
            return state;

    } //switch

    return state;   
   
//return null;
}; //end of MainReducer---------------------------


export default MainReducer;




